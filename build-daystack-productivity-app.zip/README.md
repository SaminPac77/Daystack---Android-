# DAYSTACK

**Your Day. Your Direction.** DAYSTACK is an offline-first workspace for daily tasks, notes, and projects. This is the first release, focused on a reliable local workspace before adding the full calendar, habits, or analytics.

## Run locally

```sh
npm ci
npm run dev
```

The first visit opens a **Demo workspace** with sample tasks. Use the sidebar workspace switcher or **Settings > Use my workspace** to start with an empty personal workspace. The two workspaces never share records. For the offline shell, run `npm run build && npm run preview` and visit once while online. Service workers require HTTPS or localhost and are not registered by the Vite development server.

## Optional cloud workspace

1. Apply `supabase/migrations/202611260001_workspace_records.sql` to your Supabase project, for example with the SQL editor.
2. Copy `.env.example` to `.env.local` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`. Use a publishable key (or legacy `anon` key), **never** a service-role or secret key. Vite includes these variables in the browser bundle.
3. Enable email/password authentication in Supabase. Set the site URL and allow `<your-origin>/today` as a redirect URL, including a localhost entry when testing. Rebuild the app after changing environment variables.
4. Open **Settings > Account & sync**. Create an account or sign in. If confirmation is enabled, confirm your email and select the **Cloud workspace**. Sign-in is optional and does not upload the demo or personal workspace.

Cloud records are restricted to their owner by PostgreSQL RLS. Tasks, projects, and notes in the cloud workspace write to IndexedDB and enqueue a versioned operation in the same transaction. The foreground sync worker pushes coalesced changes and reads the server snapshot. Writes retry with backoff; **Sync now** forces a retry. Tombstones preserve deletions, and version plus UTC timestamp determines conflict order. An expired or missing session may require signing in again before cloud records and uploads are available. Daily priority assignments, focus timers, and preferences are device-local.

## File map

| Path | Responsibility |
| --- | --- |
| `src/App.tsx`, `src/components/layout/` | Route composition, desktop sidebar, header, mobile navigation, dialogs |
| `src/features/` | Today and Quick Capture, task workflows, agenda, projects, notes, focus, account, and settings |
| `src/components/ui/`, `src/styles/`, `src/index.css` | Locally styled shadcn/Radix primitives, responsive layouts, and theme tokens |
| `src/domain/` | Typed entities, calendar calculations, validation, and Today selectors |
| `src/data/`, `src/app/workspace-context.tsx` | Dexie, repository transactions, sync outbox, local Query cache and Supabase transport |
| `public/sw.js`, `public/manifest.webmanifest` | Static shell caching and install metadata |
| `src/platform/`, `capacitor.config.json` | Device capabilities, lifecycle, haptics and notification adapters, and future native web directory |
| `supabase/migrations/`, `supabase/tests/` | PostgreSQL schema, RLS policies, versioned write function and RLS checks |
| `tests/e2e/`, `src/**/*.test.ts` | Playwright workflows and Vitest domain/repository tests |

Dependencies: React Router, Lucide, local Inter, Radix and CVA, Zustand, TanStack Query, Dexie, Supabase JS, Zod, React Hook Form with its Zod resolver, and Capacitor Core. Vitest, fake-indexeddb, and Playwright are development-only.

## Verify

```sh
npm run typecheck
npm test
npx playwright install chromium
npm run test:e2e
```

On Linux, `npx playwright install --with-deps chromium` can install any missing Chromium OS dependencies. The E2E suite uses the production preview. The offline test takes Chromium offline after the service worker takes control, reloads the app, creates and edits a task, and opens a new tab without reconnecting.

Run `psql "$TEST_DATABASE_URL" -X -f supabase/tests/rls.sql` on a **disposable, empty PostgreSQL database** as a role that can create roles and tables. It creates a minimal Auth fixture, asserts owner isolation and idempotent versioned writes, and rolls back. It does not test the hosted Supabase authentication flow.

## Deployment and scope

- Serve `dist/` at the origin root with an SPA fallback to `index.html`, while serving the manifest, images, and `sw.js` as static files. Revalidate `index.html` and `sw.js` on deployment. The scaffold's single-file Vite build embeds the JavaScript, CSS, and Inter font in the cached shell.
- IndexedDB is origin-local. Export a JSON backup before clearing browser data. Restore/import and local-to-cloud migration are not included in this release.
- Plan is an agenda, not a full day/week/month calendar. Focus has a persistent timer and task association, but no completed-session history or out-of-app scheduling. Habit tracking, insights, multilingual UI, and native Android packaging are deferred. The Capacitor config and adapters do not require those plugins on the web.