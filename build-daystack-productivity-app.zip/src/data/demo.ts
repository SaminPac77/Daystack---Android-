import { dayKey, dateToTimestamp, newId, shiftDay } from "@/domain/dates";
import type { Note, Project, Task, VersionedRecord } from "@/domain/models";
import { db } from "./db";

const seedKey = "demo-seeded-v1";

export async function ensureDemo() {
  return db.transaction("rw", [db.meta, db.tasks, db.projects, db.notes, db.plans], async () => {
    if (await db.meta.get(seedKey)) return;
    const now = new Date();
    const at = now.toISOString();
    const base = (): VersionedRecord => ({ id: newId(), scope: "demo", createdAt: at, updatedAt: at, deletedAt: null, version: 1 });
    const coursework: Project = { ...base(), name: "Coursework", description: "Assignments, reading, and midterm prep for this semester.", status: "active", tone: "violet" };
    const studio: Project = { ...base(), name: "Studio Website", description: "A small portfolio site for a friend, from wireframes through handoff.", status: "active", tone: "sky" };
    const personal: Project = { ...base(), name: "Personal", description: "Things to make time for outside work and school.", status: "active", tone: "sage" };
    const task = (title: string, project: Project, priority: Task["priority"], days: number, description: string, complete = false): Task => ({
      ...base(), title, description, projectId: project.id, priority,
      dueAt: dateToTimestamp(dayKey(shiftDay(now, days))), status: complete ? "completed" : "open", completedAt: complete ? at : null,
    });
    const tasks = [
      task("Finish research outline", coursework, "high", 0, "Refine the research question and outline three sections before the seminar."),
      task("Send homepage wireframes", studio, "high", 0, "Export the two homepage directions and ask for feedback on the navigation."),
      task("Review notes for midterm", coursework, "medium", 0, "Start with week three lecture notes, then turn key concepts into flashcards."),
      task("Reply to project emails", studio, "low", 0, "Confirm the feedback deadline and send the updated link.", true),
      task("Plan the week ahead", personal, "none", 0, "Block time for classes, deep work, and a walk.", true),
      task("Upload revised bibliography", coursework, "medium", -1, "Check the citation format before uploading to the class portal."),
      task("Submit design proposal", studio, "high", 1, "Include the proposed timeline and scope."),
      task("Read chapters 4-6", coursework, "medium", 3, "Take a few notes on the main themes."),
      task("Book a dentist appointment", personal, "low", 5, "Call the office during business hours."),
    ];
    const notes: Note[] = [
      { ...base(), title: "Ideas for the homepage", body: "**Keep the first screen simple.** Lead with a short introduction, then show two strong projects.\n\n- Try a quieter color palette\n- Ask about a behind-the-scenes section", projectId: studio.id },
      { ...base(), title: "Midterm study checklist", body: "- Review lecture slides\n- Make flashcards for key terms\n- Compare notes with the study group", projectId: coursework.id },
    ];
    await db.projects.bulkAdd([coursework, studio, personal]);
    await db.tasks.bulkAdd(tasks);
    await db.notes.bulkAdd(notes);
    await db.plans.add({ scope: "demo", day: dayKey(now), slots: [tasks[0].id, tasks[1].id, tasks[2].id] });
    await db.meta.add({ key: seedKey, value: at });
  });
}