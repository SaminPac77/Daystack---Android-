import type { SupabaseClient } from "@supabase/supabase-js";
import type { Scope, SyncedEntity } from "@/domain/models";
import { cloudEnvelope } from "@/domain/validation";
import { db } from "./db";
import { applyRemote, updateQueue } from "./workspace-repository";

const batchSize = 100;

export async function syncWorkspace(client: SupabaseClient, owner: string, signal: AbortSignal, force = false) {
  const scope: Scope = `account:${owner}`;
  const queue = await db.syncQueue.where("scope").equals(scope).toArray();
  let failed = false;

  for (const op of queue) {
    signal.throwIfAborted();
    if (!force && op.retryAt > Date.now()) { failed = true; continue; }
    const { scope: _localOnly, ...payload } = op.record.payload;
    let accepted = false;
    try {
      const { error } = await client.rpc("apply_daystack_record", {
        p_owner: owner, p_id: payload.id, p_kind: op.record.kind, p_payload: payload,
        p_version: payload.version, p_updated_at: payload.updatedAt,
      }).abortSignal(signal);
      accepted = !error;
    } catch {
      // A rejected request follows the same backoff as a non-success response.
    }
    signal.throwIfAborted();
    await updateQueue(op, accepted);
    failed ||= !accepted;
  }

  // Ordered paging keeps the snapshot complete beyond PostgREST's row limit.
  let cursor: string | undefined;
  do {
    const request = client.from("daystack_records").select("id,kind,payload").eq("owner_id", owner).order("id").limit(batchSize);
    const { data, error } = await (cursor ? request.gt("id", cursor) : request).abortSignal(signal);
    signal.throwIfAborted();
    if (error) throw error;
    for (const row of data ?? []) {
      signal.throwIfAborted();
      const parsed = cloudEnvelope.safeParse(row);
      if (parsed.success) {
        const { kind, payload } = parsed.data;
        await applyRemote({ kind, payload: { ...payload, scope } } as SyncedEntity);
      } else failed = true;
    }
    cursor = data?.length === batchSize ? data[batchSize - 1].id : undefined;
  } while (cursor);

  if (failed) throw new Error("Some changes could not be synced yet.");
}