import type { Table } from "dexie";
import { db } from "./db";
import { ensureDemo } from "./demo";
import { newId } from "@/domain/dates";
import { isNewer } from "@/domain/today";
import type { DayPlan, EntityKind, EntityMap, Project, Scope, SyncOperation, SyncedEntity, Task, VersionedRecord, WorkspaceData } from "@/domain/models";
import { dateField, noteFields, projectFields, taskFields, uuid, type NoteFields, type ProjectFields, type TaskFields } from "@/domain/validation";

export const workspaceWrites = new EventTarget();
const tables: { [K in EntityKind]: Table<EntityMap[K], string> } = { task: db.tasks, project: db.projects, note: db.notes };
const at = () => new Date().toISOString();
const base = (scope: Scope): VersionedRecord => {
  const stamp = at();
  return { id: newId(), scope, createdAt: stamp, updatedAt: stamp, deletedAt: null, version: 1 };
};
const bump = <T extends VersionedRecord>(value: T): T => ({ ...value, version: value.version + 1, updatedAt: at() });

export async function readWorkspace(scope: Scope): Promise<WorkspaceData> {
  return db.transaction("r", [db.tasks, db.projects, db.notes, db.plans, db.syncQueue], async () => {
    const [tasks, projects, notes, plans, pending] = await Promise.all([
      db.tasks.where("scope").equals(scope).filter((row) => !row.deletedAt).toArray(),
      db.projects.where("scope").equals(scope).filter((row) => !row.deletedAt).toArray(),
      db.notes.where("scope").equals(scope).filter((row) => !row.deletedAt).toArray(),
      db.plans.where("scope").equals(scope).toArray(),
      db.syncQueue.where("scope").equals(scope).count(),
    ]);
    return { tasks, projects, notes, plans, pending };
  });
}

export async function openWorkspace(scope: Scope) {
  if (scope === "demo") await ensureDemo();
  return readWorkspace(scope);
}

async function get<K extends EntityKind>(kind: K, id: string, scope: Scope): Promise<EntityMap[K]> {
  const record = await tables[kind].get(id);
  if (!record || record.scope !== scope || record.deletedAt) throw new Error("This item is no longer in this workspace.");
  return record;
}

async function save(record: SyncedEntity) {
  if (record.kind === "task") await db.tasks.put(record.payload);
  else if (record.kind === "project") await db.projects.put(record.payload);
  else await db.notes.put(record.payload);

  if (record.payload.scope.startsWith("account:")) {
    await db.syncQueue.put({ id: record.payload.id, scope: record.payload.scope, record, attempts: 0, retryAt: 0 });
  }
}

async function write<T>(operation: () => Promise<T>): Promise<T> {
  // Local changes and their cloud outbox either commit together or not at all.
  const result = await db.transaction("rw", [db.tasks, db.projects, db.notes, db.syncQueue, db.plans], operation);
  workspaceWrites.dispatchEvent(new Event("change"));
  return result;
}

async function assertProject(scope: Scope, id: string | null, previous?: string | null) {
  if (!id || id === previous) return;
  const project = await get("project", id, scope);
  if (project.status === "archived") throw new Error("Choose an active project or leave the project blank.");
}

export function saveTask(scope: Scope, fields: TaskFields, id?: string) {
  const data = taskFields.parse(fields);
  return write(async () => {
    const existing = id ? await get("task", id, scope) : null;
    await assertProject(scope, data.projectId, existing?.projectId);
    const task: Task = { ...(existing ? bump(existing) : { ...base(scope), status: "open", completedAt: null }), ...data };
    await save({ kind: "task", payload: task });
    return task;
  });
}

export function completeTask(scope: Scope, id: string, completed: boolean) {
  return write(async () => {
    const task = await get("task", id, scope);
    const status = completed ? "completed" : "open";
    if (task.status === status) return task;
    const updated: Task = { ...bump(task), status, completedAt: completed ? at() : null };
    await save({ kind: "task", payload: updated });
    return updated;
  });
}

export function rescheduleTask(scope: Scope, id: string, dueAt: string | null) {
  return write(async () => {
    const task = await get("task", id, scope);
    const data = taskFields.parse({ ...task, dueAt });
    await save({ kind: "task", payload: { ...bump(task), ...data } });
  });
}

export function saveProject(scope: Scope, fields: ProjectFields, id?: string) {
  const data = projectFields.parse(fields);
  return write(async () => {
    const project: Project = { ...(id ? bump(await get("project", id, scope)) : { ...base(scope), status: "active" }), ...data };
    await save({ kind: "project", payload: project });
    return project;
  });
}

export function archiveProject(scope: Scope, id: string, archive: boolean) {
  return write(async () => {
    const project = await get("project", id, scope);
    await save({ kind: "project", payload: { ...bump(project), status: archive ? "archived" : "active" } });
  });
}

export function saveNote(scope: Scope, fields: NoteFields, id?: string) {
  const data = noteFields.parse(fields);
  return write(async () => {
    const existing = id ? await get("note", id, scope) : null;
    await assertProject(scope, data.projectId, existing?.projectId);
    const note = { ...(existing ? bump(existing) : base(scope)), ...data };
    await save({ kind: "note", payload: note });
    return note;
  });
}

export function removeRecord(scope: Scope, kind: EntityKind, id: string) {
  return write(async () => {
    const deletedAt = at();
    if (kind === "task") await save({ kind, payload: { ...bump(await get(kind, id, scope)), deletedAt } });
    else if (kind === "note") await save({ kind, payload: { ...bump(await get(kind, id, scope)), deletedAt } });
    else {
      await save({ kind, payload: { ...bump(await get(kind, id, scope)), deletedAt } });
      const tasks = await db.tasks.where("[scope+projectId]").equals([scope, id]).filter((item) => !item.deletedAt).toArray();
      const notes = await db.notes.where("[scope+projectId]").equals([scope, id]).filter((item) => !item.deletedAt).toArray();
      for (const task of tasks) await save({ kind: "task", payload: { ...bump(task), projectId: null } });
      for (const note of notes) await save({ kind: "note", payload: { ...bump(note), projectId: null } });
    }
  });
}

export function saveDayPlan(scope: Scope, day: string, slots: DayPlan["slots"]) {
  if (!day || !dateField.safeParse(day).success) throw new Error("Choose a valid day.");
  const ids = slots.filter((id): id is string => id !== null);
  if (new Set(ids).size !== ids.length) throw new Error("Choose a different task for each priority.");
  return write(async () => {
    for (const id of ids) await get("task", uuid.parse(id), scope);
    await db.plans.put({ scope, day, slots });
  });
}

export async function applyRemote(record: SyncedEntity) {
  await db.transaction("rw", [db.tasks, db.projects, db.notes, db.syncQueue], async () => {
    const existing = await tables[record.kind].get(record.payload.id);
    if (existing?.scope && existing.scope !== record.payload.scope) return;
    if (existing && !isNewer(record.payload, existing)) {
      if (existing.version !== record.payload.version || existing.updatedAt !== record.payload.updatedAt) return;
      // The server breaks exact version/time ties once the local write has been acknowledged.
      if (await db.syncQueue.get(existing.id)) return;
      if (!Object.entries(record.payload).some(([key, value]) => Reflect.get(existing, key) !== value)) return;
    }
    if (record.kind === "task") await db.tasks.put(record.payload);
    else if (record.kind === "note") await db.notes.put(record.payload);
    else await db.projects.put(record.payload);
  });
}

export async function updateQueue(sent: SyncOperation, success: boolean) {
  await db.transaction("rw", db.syncQueue, async () => {
    const active = await db.syncQueue.get(sent.id);
    if (!active || active.record.payload.version !== sent.record.payload.version || active.record.payload.updatedAt !== sent.record.payload.updatedAt) return;
    if (success) await db.syncQueue.delete(sent.id);
    else await db.syncQueue.put({ ...active, attempts: active.attempts + 1, retryAt: Date.now() + Math.min(60_000, 1000 * 2 ** Math.min(active.attempts + 1, 6)) });
  });
}