import "fake-indexeddb/auto";
import { beforeEach, describe, expect, it } from "vitest";
import { db } from "./db";
import { applyRemote, archiveProject, completeTask, openWorkspace, readWorkspace, removeRecord, saveDayPlan, saveNote, saveProject, saveTask, updateQueue } from "./workspace-repository";
import { dayKey } from "@/domain/dates";

const account = "account:0bcf854b-43f9-4594-9d58-69aededb156a" as const;
const fields = { title: "Write the brief", description: "Draft two goals", priority: "medium", projectId: null, dueAt: null } as const;
const projectFields = { name: "Website", description: "Portfolio refresh", tone: "violet" } as const;

beforeEach(async () => {
  await db.transaction("rw", db.tables, async () => { await Promise.all(db.tables.map((table) => table.clear())); });
});

describe("IndexedDB workspace repository", () => {
  it("seeds the progress demo once and never seeds a personal workspace", async () => {
    const demo = await openWorkspace("demo");
    expect(demo.tasks).toHaveLength(9);
    expect(demo.tasks.filter(({ status }) => status === "completed")).toHaveLength(2);
    expect((await openWorkspace("demo")).tasks.map(({ id }) => id)).toEqual(demo.tasks.map(({ id }) => id));
    expect((await openWorkspace("local")).tasks).toEqual([]);
    expect(demo.pending).toBe(0);
  });

  it("creates, saves, completes and tombstones a task without a network", async () => {
    const original = await saveTask("local", fields);
    const changed = await saveTask("local", { ...fields, title: "Updated brief" }, original.id);
    expect(changed.version).toBe(2);
    const done = await completeTask("local", original.id, true);
    expect(done.status).toBe("completed");
    expect(done.completedAt).toMatch(/Z$/);
    await expect(completeTask("demo", original.id, false)).rejects.toThrow();
    await removeRecord("local", "task", original.id);
    expect((await readWorkspace("local")).tasks).toEqual([]);
    expect((await db.tasks.get(original.id))?.deletedAt).toBeTruthy();
    expect(await db.syncQueue.count()).toBe(0);
  });

  it("archives a project and detaches records on deletion", async () => {
    const project = await saveProject("local", projectFields);
    await saveTask("local", { ...fields, projectId: project.id });
    await saveNote("local", { title: "Creative brief", body: "Draft", projectId: project.id });
    await archiveProject("local", project.id, true);
    await expect(saveTask("local", { ...fields, projectId: project.id })).rejects.toThrow("active project");
    await removeRecord("local", "project", project.id);
    const data = await readWorkspace("local");
    expect(data.projects).toHaveLength(0);
    expect(data.tasks[0].projectId).toBeNull();
    expect(data.notes[0].projectId).toBeNull();
  });

  it("protects distinct and workspace-owned priority slots", async () => {
    const task = await saveTask("local", fields);
    const day = dayKey(new Date());
    expect(() => saveDayPlan("local", day, [task.id, task.id, null])).toThrow("different task");
    await expect(saveDayPlan("demo", day, [task.id, null, null])).rejects.toThrow();
    await saveDayPlan("local", day, [null, task.id, null]);
    expect((await readWorkspace("local")).plans[0].slots).toEqual([null, task.id, null]);
  });

  it("coalesces the outbox and never acknowledges a more recent local edit", async () => {
    const task = await saveTask(account, fields);
    const first = (await db.syncQueue.get(task.id))!;
    await saveTask(account, { ...fields, title: "Second revision" }, task.id);
    await updateQueue(first, true);
    expect((await readWorkspace(account)).pending).toBe(1);
    const latest = (await db.syncQueue.get(task.id))!;
    expect(latest.record.payload.version).toBe(2);
    await updateQueue(latest, false);
    const retry = (await db.syncQueue.get(task.id))!;
    expect(retry.attempts).toBe(1);
    expect(retry.retryAt).toBeGreaterThan(Date.now());
    await updateQueue(retry, true);
    expect((await readWorkspace(account)).pending).toBe(0);
  });

  it("ignores stale remote versions and keeps database identity stable", async () => {
    const task = await saveTask(account, fields);
    const update = await completeTask(account, task.id, true);
    await applyRemote({ kind: "task", payload: task });
    expect((await db.tasks.get(task.id))?.version).toBe(update.version);
    await applyRemote({ kind: "task", payload: { ...update, version: update.version + 1, title: "Remote title" } });
    expect((await readWorkspace(account)).tasks.map(({ title }) => title)).toEqual(["Remote title"]);
  });

  it("reconciles an exact-timestamp tie with the server only after acknowledgment", async () => {
    const task = await saveTask(account, fields);
    const remote = { ...task, title: "Server winner" };
    await applyRemote({ kind: "task", payload: remote });
    expect((await db.tasks.get(task.id))?.title).toBe(fields.title);
    await updateQueue((await db.syncQueue.get(task.id))!, true);
    await applyRemote({ kind: "task", payload: remote });
    expect((await db.tasks.get(task.id))?.title).toBe(remote.title);
  });
});