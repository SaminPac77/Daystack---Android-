import Dexie, { type Table } from "dexie";
import type { DayPlan, Note, Project, Scope, SyncOperation, Task } from "@/domain/models";

export class DaystackDatabase extends Dexie {
  tasks!: Table<Task, string>;
  projects!: Table<Project, string>;
  notes!: Table<Note, string>;
  plans!: Table<DayPlan, [Scope, string]>;
  syncQueue!: Table<SyncOperation, string>;
  meta!: Table<{ key: string; value: string }, string>;

  constructor(name = "daystack") {
    super(name);
    this.version(1).stores({
      tasks: "id, scope, [scope+projectId]",
      projects: "id, scope",
      notes: "id, scope, [scope+projectId]",
      plans: "[scope+day], scope",
      syncQueue: "id, scope, retryAt",
      meta: "key",
    });
  }
}

export const db = new DaystackDatabase();