import type { Session } from "@supabase/supabase-js";
import { authFields } from "@/domain/validation";
import { supabase } from "./supabase";

export const cloudAuthConfigured = !!supabase;

export function observeSession(onSession: (session: Session | null) => void) {
  const subscription = supabase?.auth.onAuthStateChange((_event, session) => onSession(session));
  return () => subscription?.data.subscription.unsubscribe();
}

export async function authenticate(input: unknown, createAccount: boolean) {
  if (!supabase) throw new Error("Cloud sign-in is not configured.");
  const credentials = authFields.parse(input);
  const { data, error } = createAccount
    ? await supabase.auth.signUp({ ...credentials, options: { emailRedirectTo: new URL("/today", window.location.origin).href } })
    : await supabase.auth.signInWithPassword(credentials);
  if (error) throw error;
  return data.session;
}

export async function signOutThisDevice() {
  const { error } = await supabase?.auth.signOut({ scope: "local" }) ?? {};
  if (error) throw error;
}