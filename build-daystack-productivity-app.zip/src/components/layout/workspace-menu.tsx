import { ChevronsUpDown, Cloud, FlaskConical, HardDrive, LogIn, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/app/auth-context";
import { usePreferences, type WorkspaceMode } from "@/app/preferences";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { Dropdown, DropdownContent, DropdownItem, DropdownLabel, DropdownSeparator, DropdownTrigger } from "../ui/dropdown";

export function useSwitchWorkspace() {
  const setMode = usePreferences((state) => state.setMode);
  const close = useUi((state) => state.closeDialogs);
  const navigate = useNavigate();
  return (mode: WorkspaceMode) => { close(); setMode(mode); navigate("/today"); };
}

export function WorkspaceMenu({ collapsed }: { collapsed: boolean }) {
  const { scope } = useWorkspace();
  const { session } = useAuth();
  const saved = usePreferences((state) => state.names[scope]);
  const signIn = useUi((state) => state.setAuthentication);
  const change = useSwitchWorkspace();
  const navigate = useNavigate();
  const demo = scope === "demo";
  const name = demo ? "Alex Morgan" : saved || (scope.startsWith("account:") ? session?.user.email : null) || "My workspace";
  const subtitle = demo ? "Demo workspace" : scope === "local" ? "Personal workspace" : "Signed-in workspace";
  const initials = name.split(/[\s@._-]+/).filter(Boolean).slice(0, 2).map((value) => value[0]).join("").toUpperCase();
  return (
    <Dropdown modal={false}>
      <DropdownTrigger asChild>
        <button className="workspace-trigger" aria-label={`Switch workspace (${subtitle})`} title={collapsed ? subtitle : undefined}>
          <span className="avatar">{initials}</span>
          {!collapsed && <><span className="workspace-identity"><strong>{name}</strong><small>{subtitle}</small></span><ChevronsUpDown size={15} className="workspace-chevron" /></>}
        </button>
      </DropdownTrigger>
      <DropdownContent side="top" align="start" className="workspace-menu-content">
        <DropdownLabel>Switch workspace</DropdownLabel>
        <DropdownItem onSelect={() => change("local")}><HardDrive size={16} /> My personal workspace{scope === "local" && <span className="menu-dot" />}</DropdownItem>
        <DropdownItem onSelect={() => change("demo")}><FlaskConical size={16} /> Demo workspace{demo && <span className="menu-dot" />}</DropdownItem>
        {session ? <DropdownItem onSelect={() => change("account")}><Cloud size={16} /> Cloud workspace{scope.startsWith("account:") && <span className="menu-dot" />}</DropdownItem> : <DropdownItem onSelect={() => signIn(true)}><LogIn size={16} /> Sign in</DropdownItem>}
        <DropdownSeparator />
        <DropdownItem onSelect={() => navigate("/settings")}><Settings size={16} /> Settings</DropdownItem>
      </DropdownContent>
    </Dropdown>
  );
}