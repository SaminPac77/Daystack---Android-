import { Plus } from "lucide-react";
import { NavLink } from "react-router-dom";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { mobileNavigation } from "./navigation";

export function MobileNavigation() {
  const capture = useUi((state) => state.setCapture);
  const { loading, problem } = useWorkspace();
  return (
    <>
      <button className="mobile-capture" onClick={() => capture({ type: "task" })} aria-label="Quick Capture" disabled={loading || problem}><Plus size={25} /></button>
      <nav className="mobile-navigation" aria-label="Mobile navigation">
        {mobileNavigation.map(({ path, icon: Icon, label }) => <NavLink key={path} to={path} className="mobile-link"><Icon size={21} strokeWidth={1.8} /><span>{label}</span></NavLink>)}
      </nav>
    </>
  );
}