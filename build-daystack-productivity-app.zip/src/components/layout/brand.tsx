import { Link } from "react-router-dom";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link className="brand" to="/today" aria-label="DAYSTACK, Today">
      <svg className="brand-mark" viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" rx="15" fill="#101B30" />
        <g stroke="#D8B879" strokeWidth="2.8" strokeLinejoin="round" strokeLinecap="round" fill="none">
          <path d="m17 26 15-8 15 8-15 8z" /><path d="m17 33 15 8 15-8M17 40l15 8 15-8" />
        </g>
      </svg>
      {!compact && <span className="brand-text"><strong>DAYSTACK</strong><small>Your Day. Your Direction.</small></span>}
    </Link>
  );
}