import { ChevronRight, Moon, Plus, Search, Sun, WifiOff } from "lucide-react";
import { useLocation } from "react-router-dom";
import { usePreferences } from "@/app/preferences";
import { useResolvedTheme } from "@/app/hooks";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { Button } from "../ui/button";
import { Brand } from "./brand";
import { navigation, settingsNavigation } from "./navigation";

export function AppHeader() {
  const { pathname } = useLocation();
  const { scope, online, loading, problem } = useWorkspace();
  const dark = useResolvedTheme() === "dark";
  const setTheme = usePreferences((state) => state.setTheme);
  const search = useUi((state) => state.setSearch);
  const capture = useUi((state) => state.setCapture);
  const label = [...navigation, settingsNavigation].find(({ path }) => pathname.startsWith(path))?.label ?? "Today";
  const command = /Mac|iPhone|iPad/.test(navigator.platform) ? "Cmd K" : "Ctrl K";
  return (
    <header className="app-header">
      <div className="mobile-brand"><Brand /></div>
      <div className="header-location"><span>Workspace</span><ChevronRight size={13} aria-hidden="true" /><strong>{label}</strong></div>
      <div className="header-actions">
        {!online && <span className="header-offline" role="status" title="Offline. Changes are saved on this device."><WifiOff size={15} /><span>Offline</span></span>}
        {scope === "demo" && online && <span className="header-demo" title="Example records are stored in a separate demo workspace.">Demo</span>}
        <button className="search-trigger" onClick={() => search(true)} aria-label="Search workspace" disabled={loading || problem}><Search size={17} strokeWidth={1.8} /><span>Search anything...</span><kbd>{command}</kbd></button>
        <Button onClick={() => capture({ type: "task" })} className="header-capture" disabled={loading || problem}><Plus size={17} /> Quick Capture</Button>
        <Button variant="ghost" size="icon" className="theme-quick" onClick={() => setTheme(dark ? "light" : "dark")} aria-label={dark ? "Switch to light theme" : "Switch to dark theme"} title={dark ? "Light theme" : "Dark theme"}>{dark ? <Sun size={18} /> : <Moon size={17} />}</Button>
      </div>
    </header>
  );
}