import { PanelLeftClose, PanelLeftOpen, WifiOff } from "lucide-react";
import { NavLink } from "react-router-dom";
import { usePreferences } from "@/app/preferences";
import { useWorkspace } from "@/app/workspace-context";
import { Brand } from "./brand";
import { navigation, settingsNavigation } from "./navigation";
import { WorkspaceMenu } from "./workspace-menu";
import { Button } from "../ui/button";

export function AppSidebar() {
  const collapsed = usePreferences((state) => state.collapsed);
  const toggle = usePreferences((state) => state.toggleSidebar);
  const { online, data, scope, sync } = useWorkspace();
  const status = !online ? "Offline" : data.pending ? `${data.pending} pending sync` : sync === "error" ? "Sync needs attention" : scope.startsWith("account:") ? sync === "syncing" ? "Syncing..." : sync === "ready" ? "Synced" : "Cloud workspace" : "Saved on this device";
  return (
    <aside className="app-sidebar">
      <div className="sidebar-brand"><Brand compact={collapsed} />{!collapsed && <Button variant="ghost" size="icon" className="collapse-button" aria-label="Collapse sidebar" onClick={toggle}><PanelLeftClose size={17} /></Button>}</div>
      {collapsed && <Button variant="ghost" size="icon" className="expand-button" aria-label="Expand sidebar" title="Expand sidebar" onClick={toggle}><PanelLeftOpen size={18} /></Button>}
      <nav aria-label="Workspace" className="sidebar-navigation">
        <p className="nav-label">Workspace</p>
        <div className="nav-links">
          {navigation.map(({ path, icon: Icon, label }) => <NavLink key={path} to={path} className="sidebar-link" title={collapsed ? label : undefined} aria-label={label}><Icon size={18} strokeWidth={1.8} /><span>{label}</span></NavLink>)}
        </div>
        <div className="nav-divider" />
        <NavLink to={settingsNavigation.path} className="sidebar-link" aria-label="Settings" title={collapsed ? "Settings" : undefined}><settingsNavigation.icon size={18} strokeWidth={1.8} /><span>Settings</span></NavLink>
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-status" aria-label={`${online ? "Online" : "Offline"}. ${status}`} title={online ? `Online. ${status}.` : "Offline. Changes are saved locally."}>
          {online ? <span className={`status-dot${data.pending || sync === "error" ? " pending" : ""}`} /> : <WifiOff size={15} />}
          {!collapsed && (online && !scope.startsWith("account:") ? <><span>Online</span><span className="status-storage">Local storage</span></> : <span>{status}</span>)}
        </div>
        <WorkspaceMenu collapsed={collapsed} />
      </div>
    </aside>
  );
}