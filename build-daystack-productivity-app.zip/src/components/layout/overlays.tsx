import { CheckCircle2, CircleAlert, Info, X } from "lucide-react";
import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { useUi } from "@/app/ui-store";
import { useWorkspace, workspaceKey } from "@/app/workspace-context";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { removeRecord } from "@/data/workspace-repository";
import { AuthDialog } from "@/features/auth/auth-dialog";
import { QuickCaptureDialog } from "@/features/capture/quick-capture-dialog";
import { SearchDialog } from "@/features/search/search-dialog";
import { Button } from "@/components/ui/button";

export function Overlays() {
  const { scope, loading, problem } = useWorkspace();
  const { capture, search, authentication, deletion, setDeletion, notify } = useUi();
  const cache = useQueryClient();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handle = (event: KeyboardEvent) => {
      if (event.defaultPrevented || loading || problem || !(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "k") return;
      const state = useUi.getState();
      event.preventDefault();
      if (state.capture || state.authentication || state.deletion) return;
      if (event.shiftKey) { state.setSearch(false); state.setCapture({ type: "task" }); }
      else state.setSearch(!state.search);
    };
    window.addEventListener("keydown", handle);
    return () => window.removeEventListener("keydown", handle);
  }, [loading, problem]);

  return <>
    {capture && <QuickCaptureDialog key={`${scope}-${capture.type}-${capture.id ?? "new"}`} request={capture} />}
    {search && <SearchDialog key={scope} />}
    {authentication && <AuthDialog />}
    {deletion && <ConfirmDialog key={deletion.id} title={`Delete ${deletion.kind}?`} label={`Delete ${deletion.kind}`} description={deletion.kind === "project" ? `Delete "${deletion.title}"? Its tasks and notes will stay in your workspace without a project.` : `"${deletion.title}" will be removed from this workspace.`} onClose={() => setDeletion(null)} onConfirm={async () => {
      await removeRecord(scope, deletion.kind, deletion.id);
      await cache.invalidateQueries({ queryKey: workspaceKey(scope) });
      notify(`${deletion.kind === "task" ? "Task" : deletion.kind === "note" ? "Note" : "Project"} deleted.`);
      if (deletion.kind === "project" && location.pathname === `/projects/${deletion.id}`) navigate("/projects", { replace: true });
    }} />}
    <Toast />
  </>;
}

function Toast() {
  const toast = useUi((state) => state.toast);
  const clear = useUi((state) => state.clearToast);
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => clear(toast.key), 3800);
    return () => window.clearTimeout(id);
  }, [toast, clear]);
  if (!toast) return null;
  const Icon = toast.kind === "error" ? CircleAlert : toast.kind === "info" ? Info : CheckCircle2;
  return <div className={`toast toast-${toast.kind}`} key={toast.key} role={toast.kind === "error" ? "alert" : "status"}><Icon size={18} /><span>{toast.message}</span><Button variant="ghost" size="icon" onClick={() => clear(toast.key)} aria-label="Dismiss notification"><X size={15} /></Button></div>;
}