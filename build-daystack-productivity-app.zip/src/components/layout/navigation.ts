import { CalendarDays, ChartNoAxesColumnIncreasing, Flame, FolderOpen, NotebookPen, Settings, Sun, Timer, UserRound } from "lucide-react";

export const navigation = [
  { path: "/today", label: "Today", icon: Sun },
  { path: "/plan", label: "Plan", icon: CalendarDays },
  { path: "/projects", label: "Projects", icon: FolderOpen },
  { path: "/focus", label: "Focus", icon: Timer },
  { path: "/notes", label: "Notes", icon: NotebookPen },
  { path: "/habits", label: "Habits", icon: Flame },
  { path: "/insights", label: "Insights", icon: ChartNoAxesColumnIncreasing },
];
export const settingsNavigation = { path: "/settings", label: "Settings", icon: Settings };
export const mobileNavigation = [...navigation.slice(0, 4), { path: "/settings", label: "Profile", icon: UserRound }];