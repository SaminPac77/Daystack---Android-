import { CircleAlert, Inbox, LoaderCircle, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "./ui/button";

export function EmptyState({ title, description, icon: Icon = Inbox, action, compact }: { title: string; description?: string; icon?: LucideIcon; action?: ReactNode; compact?: boolean }) {
  return (
    <div className={`empty-state${compact ? " empty-compact" : ""}`}>
      <span className="state-icon"><Icon size={compact ? 18 : 23} aria-hidden="true" /></span>
      <div><h3>{title}</h3>{description && <p>{description}</p>}</div>
      {action}
    </div>
  );
}

export function LoadingState({ message = "Opening your workspace" }: { message?: string }) {
  return <div className="loading-state" role="status"><LoaderCircle className="spin" size={20} /><span>{message}</span></div>;
}

export function ErrorState({ retry }: { retry: () => void }) {
  return <div className="panel"><EmptyState icon={CircleAlert} title="Your workspace couldn't open" description="Check that this browser allows local storage, then try again." action={<Button onClick={retry} variant="outline">Try again</Button>} /></div>;
}