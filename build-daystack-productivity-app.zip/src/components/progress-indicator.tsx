export function ProgressIndicator({ value, circular = false, label = "Completion progress" }: { value: number; circular?: boolean; label?: string }) {
  const percent = Math.min(100, Math.max(0, Math.round(value)));
  const progress = { role: "progressbar", "aria-label": label, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent };
  if (!circular) return <div {...progress} className="progress-track"><span style={{ width: `${percent}%` }} /></div>;

  return (
    <div {...progress} className="progress-circle">
      <svg viewBox="0 0 96 96" aria-hidden="true">
        <circle cx="48" cy="48" r="40" className="ring-track" />
        <circle cx="48" cy="48" r="40" transform="rotate(-90 48 48)" className="ring-fill" pathLength="100" strokeDasharray={`${percent} 100`} style={percent === 0 ? { opacity: 0 } : undefined} />
      </svg>
      <strong aria-hidden="true">{percent}<span>%</span></strong>
    </div>
  );
}