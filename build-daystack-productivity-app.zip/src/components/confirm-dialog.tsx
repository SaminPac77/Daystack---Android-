import { useState } from "react";
import { Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";

export function ConfirmDialog({ title, description, onConfirm, onClose, label = "Delete" }: { title: string; description: string; onConfirm: () => Promise<void>; onClose: () => void; label?: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);
  return (
    <Dialog open onOpenChange={(open) => { if (!open && !busy) onClose(); }}>
      <DialogContent className="confirm-dialog">
        <span className="modal-icon danger-icon"><Trash2 size={20} /></span>
        <DialogTitle>{title}</DialogTitle>
        <DialogDescription>{description}</DialogDescription>
        {error && <p role="alert" className="form-error">That item couldn't be deleted. Try again.</p>}
        <div className="dialog-actions">
          <Button variant="outline" onClick={onClose} disabled={busy} data-initial-focus>Cancel</Button>
          <Button variant="danger" disabled={busy} onClick={async () => {
            setBusy(true); setError(false);
            try { await onConfirm(); onClose(); } catch { setError(true); } finally { setBusy(false); }
          }}>{busy ? "Deleting..." : label}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}