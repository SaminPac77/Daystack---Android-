import * as Primitive from "@radix-ui/react-dropdown-menu";
import type { ComponentProps } from "react";
import { cn } from "@/utils/cn";

export const Dropdown = Primitive.Root;
export const DropdownTrigger = Primitive.Trigger;
export const DropdownSeparator = () => <Primitive.Separator className="dropdown-separator" />;
export const DropdownLabel = ({ className, ...props }: ComponentProps<typeof Primitive.Label>) => <Primitive.Label className={cn("dropdown-label", className)} {...props} />;
export const DropdownItem = ({ className, ...props }: ComponentProps<typeof Primitive.Item>) => <Primitive.Item className={cn("dropdown-item", className)} {...props} />;

export function DropdownContent({ className, sideOffset = 7, ...props }: ComponentProps<typeof Primitive.Content>) {
  return <Primitive.Portal><Primitive.Content sideOffset={sideOffset} className={cn("dropdown-content", className)} {...props} /></Primitive.Portal>;
}