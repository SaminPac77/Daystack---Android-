import * as Primitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { useRef, type ComponentProps } from "react";
import { cn } from "@/utils/cn";
import { Button } from "./button";

export const Dialog = Primitive.Root;
export const DialogTitle = ({ className, ...props }: ComponentProps<typeof Primitive.Title>) => <Primitive.Title className={cn("dialog-title", className)} {...props} />;
export const DialogDescription = ({ className, ...props }: ComponentProps<typeof Primitive.Description>) => <Primitive.Description className={cn("dialog-description", className)} {...props} />;

export function DialogContent({ children, className, ...props }: ComponentProps<typeof Primitive.Content>) {
  const previous = useRef<HTMLElement | null>(null);
  return (
    <Primitive.Portal>
      <Primitive.Overlay className="dialog-overlay" />
      <Primitive.Content
        className={cn("dialog-content", className)}
        onOpenAutoFocus={(event) => {
          previous.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
          const target = (event.target as HTMLElement | null)?.querySelector<HTMLElement>("[data-initial-focus]");
          if (target) { event.preventDefault(); target.focus(); }
        }}
        onCloseAutoFocus={(event) => {
          if (previous.current?.isConnected && previous.current !== document.body) {
            event.preventDefault();
            previous.current.focus();
          }
        }}
        {...props}
      >
        {children}
        <Primitive.Close asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Close dialog"><X size={18} /></Button></Primitive.Close>
      </Primitive.Content>
    </Primitive.Portal>
  );
}