import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentProps } from "react";
import { cn } from "@/utils/cn";

const buttonVariants = cva("button", {
  variants: {
    variant: { default: "button-primary", outline: "button-outline", ghost: "button-ghost", soft: "button-soft", danger: "button-danger" },
    size: { default: "button-default", sm: "button-sm", icon: "button-icon", lg: "button-lg" },
  },
  defaultVariants: { variant: "default", size: "default" },
});

interface Props extends ComponentProps<"button">, VariantProps<typeof buttonVariants> { asChild?: boolean }

export function Button({ className, variant, size, asChild, type, ...props }: Props) {
  const Component = asChild ? Slot : "button";
  return <Component className={cn(buttonVariants({ variant, size }), className)} {...(!asChild ? { type: type ?? "button" } : {})} {...props} />;
}