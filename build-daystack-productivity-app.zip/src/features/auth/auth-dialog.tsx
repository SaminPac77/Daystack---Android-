import { zodResolver } from "@hookform/resolvers/zod";
import { Cloud, KeyRound } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useUi } from "@/app/ui-store";
import { useOnline } from "@/app/hooks";
import { useSwitchWorkspace } from "@/components/layout/workspace-menu";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { authFields } from "@/domain/validation";
import { authenticate, cloudAuthConfigured } from "@/data/auth-repository";

export function AuthDialog() {
  const close = useUi((state) => state.setAuthentication);
  const notify = useUi((state) => state.notify);
  const switchWorkspace = useSwitchWorkspace();
  const online = useOnline();
  const [registerAccount, setRegisterAccount] = useState(false);
  const [message, setMessage] = useState("");
  const { register, handleSubmit, setError, clearErrors, formState: { errors, isSubmitting } } = useForm<z.infer<typeof authFields>>({ resolver: zodResolver(authFields), defaultValues: { email: "", password: "" } });
  return <Dialog open onOpenChange={(open) => { if (!open && !isSubmitting) close(false); }}>
    <DialogContent>
      <span className="modal-icon">{cloudAuthConfigured ? <KeyRound size={20} /> : <Cloud size={21} />}</span>
      <DialogTitle>{!cloudAuthConfigured ? "Cloud sign-in is unavailable" : registerAccount ? "Create your DAYSTACK account" : "Sign in to DAYSTACK"}</DialogTitle>
      <DialogDescription>{cloudAuthConfigured ? "Sign in to use a separate workspace that syncs across your devices." : "This deployment is local-only. You can still use every local workspace feature without an account."}</DialogDescription>
      {cloudAuthConfigured ? <form className="dialog-form" noValidate onSubmit={handleSubmit(async (values) => {
        clearErrors("root"); setMessage("");
        if (!online) return;
        try {
          const session = await authenticate(values, registerAccount);
          if (session) { switchWorkspace("account"); notify("You're signed in."); }
          else setMessage("Check your inbox for a confirmation link, then sign in here.");
        } catch (error) { setError("root", { message: error instanceof Error ? error.message : "Sign-in failed. Please try again." }); }
      })}>
        <label className="field"><span>Email</span><input type="email" className="form-control" placeholder="you@example.com" autoComplete="email" data-initial-focus {...register("email")} />{errors.email && <small className="form-error">{errors.email.message}</small>}</label>
        <label className="field"><span>Password</span><input type="password" className="form-control" autoComplete={registerAccount ? "new-password" : "current-password"} placeholder="At least 8 characters" {...register("password")} />{errors.password && <small className="form-error">{errors.password.message}</small>}</label>
        {errors.root && <p className="form-error" role="alert">{errors.root.message}</p>}
        {message && <p className="field-hint" role="status">{message}</p>}
        {!online && <p className="form-error">Connect to the internet to sign in.</p>}
        <div className="dialog-actions auth-actions"><button className="inline-link" type="button" onClick={() => { setRegisterAccount(!registerAccount); setMessage(""); clearErrors(); }}>{registerAccount ? "Back to sign in" : "Create an account"}</button><Button type="submit" disabled={isSubmitting || !online}>{isSubmitting ? "Please wait..." : registerAccount ? "Sign up" : "Sign in"}</Button></div>
      </form> : <div className="dialog-actions"><Button onClick={() => switchWorkspace("local")}>Open my workspace</Button></div>}
    </DialogContent>
  </Dialog>;
}