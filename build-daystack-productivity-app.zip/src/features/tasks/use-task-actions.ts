import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useWorkspace, workspaceKey } from "@/app/workspace-context";
import { useUi } from "@/app/ui-store";
import { completeTask, rescheduleTask } from "@/data/workspace-repository";
import { type Task, type WorkspaceData } from "@/domain/models";
import { dateToTimestamp, dayKey } from "@/domain/dates";
import { platform } from "@/platform/platform";

export function useTaskActions() {
  const { scope } = useWorkspace();
  const cache = useQueryClient();
  const notify = useUi((state) => state.notify);
  const queryKey = workspaceKey(scope);
  const invalidate = () => cache.invalidateQueries({ queryKey });
  const toggle = useMutation({
    networkMode: "always",
    mutationFn: ({ id, done }: { id: string; done: boolean }) => completeTask(scope, id, done),
    onMutate: async ({ id, done }) => {
      await cache.cancelQueries({ queryKey });
      const previous = cache.getQueryData<WorkspaceData>(queryKey)?.tasks.find((item) => item.id === id);
      cache.setQueryData<WorkspaceData>(queryKey, (data) => data && { ...data, tasks: data.tasks.map((task) => task.id === id ? { ...task, status: done ? "completed" : "open", completedAt: done ? new Date().toISOString() : null } : task) });
      return { previous };
    },
    onSuccess: () => { void platform.lightFeedback().catch(() => {}); },
    onError: (_error, { id }, context) => {
      const previous = context?.previous;
      if (previous) cache.setQueryData<WorkspaceData>(queryKey, (data) => data && { ...data, tasks: data.tasks.map((task) => task.id === id ? previous : task) });
      notify("Couldn't update the task. Try again.", "error");
    },
    onSettled: invalidate,
  });
  const move = useMutation({
    networkMode: "always",
    mutationFn: (id: string) => rescheduleTask(scope, id, dateToTimestamp(dayKey(new Date()))),
    onSuccess: () => { notify("Task moved to today."); },
    onError: () => { notify("Couldn't reschedule the task.", "error"); },
    onSettled: invalidate,
  });
  return {
    toggle: (task: Task) => toggle.mutate({ id: task.id, done: task.status !== "completed" }),
    moveToToday: (task: Task) => move.mutate(task.id),
    busy: toggle.isPending,
  };
}