import { CalendarDays, Check, Ellipsis, Flag, Pencil, Trash2 } from "lucide-react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { readableDate } from "@/domain/dates";
import type { Priority, Project, Task } from "@/domain/models";
import { Button } from "@/components/ui/button";
import { Dropdown, DropdownContent, DropdownItem, DropdownSeparator, DropdownTrigger } from "@/components/ui/dropdown";
import { useTaskActions } from "./use-task-actions";

const priorityNames: Record<Priority, string> = { none: "No priority", low: "Low", medium: "Medium", high: "High" };

export function PriorityBadge({ priority }: { priority: Priority }) {
  if (priority === "none") return null;
  return <span className={`priority-badge priority-${priority}`}><Flag size={12} strokeWidth={1.9} aria-hidden="true" />{priorityNames[priority]}</span>;
}

export function ProjectLabel({ project }: { project: Project }) {
  return <span className={`project-label tone-${project.tone}`}><span />{project.name}</span>;
}

export function TaskCard({ task, showDue }: { task: Task; showDue?: boolean }) {
  const { data } = useWorkspace();
  const capture = useUi((state) => state.setCapture);
  const deleteItem = useUi((state) => state.setDeletion);
  const { toggle, moveToToday, busy } = useTaskActions();
  const checked = task.status === "completed";
  const project = data.projects.find(({ id }) => id === task.projectId);
  const edit = () => capture({ type: "task", id: task.id });
  return (
    <li className={checked ? "task-row task-done" : "task-row"}>
      <button className="task-toggle" type="button" role="checkbox" aria-checked={checked} aria-label={`Complete ${task.title}`} disabled={busy} onClick={() => toggle(task)}>
        <span>{checked && <Check size={12} strokeWidth={2.6} />}</span>
      </button>
      <div className="task-main">
        <button className="task-title" onClick={edit}>{task.title}</button>
        <div className="task-meta">{project && <ProjectLabel project={project} />}{showDue && task.dueAt && <span className="task-date"><CalendarDays size={12} />{readableDate(task.dueAt, { month: "short", day: "numeric" })}</span>}</div>
      </div>
      <div className="task-trailing">
        <PriorityBadge priority={task.priority} />
        <Dropdown modal={false}>
          <DropdownTrigger asChild><Button variant="ghost" size="icon" className="task-menu" aria-label={`Actions for ${task.title}`}><Ellipsis size={18} /></Button></DropdownTrigger>
          <DropdownContent align="end">
            <DropdownItem onSelect={edit}><Pencil size={15} /> Edit task</DropdownItem>
            {!checked && <DropdownItem onSelect={() => moveToToday(task)}><CalendarDays size={15} /> Move to today</DropdownItem>}
            <DropdownSeparator />
            <DropdownItem className="danger-text" onSelect={() => deleteItem({ kind: "task", id: task.id, title: task.title })}><Trash2 size={15} /> Delete task</DropdownItem>
          </DropdownContent>
        </Dropdown>
      </div>
    </li>
  );
}