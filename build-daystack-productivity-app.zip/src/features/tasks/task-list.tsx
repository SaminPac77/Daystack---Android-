import { ArrowDownWideNarrow, Check, ListChecks, Plus } from "lucide-react";
import { useState } from "react";
import type { Task } from "@/domain/models";
import { EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Dropdown, DropdownContent, DropdownItem, DropdownLabel, DropdownTrigger } from "@/components/ui/dropdown";
import { TaskCard } from "./task-card";

const filters = [{ label: "All tasks", value: "all" }, { label: "Open", value: "open" }, { label: "Completed", value: "completed" }] as const;
const sortOptions = [{ label: "Default order", id: "default" }, { label: "Due date", id: "due" }, { label: "Title A-Z", id: "title" }] as const;

export function TaskList({ tasks, filterable, showDue, onAdd, emptyTitle = "No tasks yet" }: { tasks: Task[]; filterable?: boolean; showDue?: boolean; onAdd?: () => void; emptyTitle?: string }) {
  const [filter, setFilter] = useState<typeof filters[number]["value"]>("all");
  const [sort, setSort] = useState<typeof sortOptions[number]["id"]>("default");
  let rows = filter === "all" ? tasks : tasks.filter(({ status }) => status === filter);
  if (sort !== "default") rows = rows.slice().sort((a, b) => sort === "title" ? a.title.localeCompare(b.title) : (a.dueAt ?? "z").localeCompare(b.dueAt ?? "z"));

  return (
    <div className="panel task-list-panel">
      {filterable && <div className="task-list-toolbar">
        <div className="task-filters" role="group" aria-label="Task filter">
          {filters.map(({ label, value }) => <button key={value} aria-pressed={filter === value} onClick={() => setFilter(value)}>{label}{value === "all" && <span>{tasks.length}</span>}</button>)}
        </div>
        <Dropdown modal={false}>
          <DropdownTrigger asChild><Button variant="ghost" size="icon" className="sort-tasks" aria-label="Sort tasks"><ArrowDownWideNarrow size={17} /></Button></DropdownTrigger>
          <DropdownContent align="end"><DropdownLabel>Sort by</DropdownLabel>{sortOptions.map(({ id, label }) => <DropdownItem key={id} onSelect={() => setSort(id)}>{label}{sort === id && <Check className="ml-auto" size={14} />}</DropdownItem>)}</DropdownContent>
        </Dropdown>
      </div>}
      {rows.length ? <ul className="task-list">{rows.map((task) => <TaskCard key={task.id} task={task} showDue={showDue} />)}</ul> : (
        <EmptyState compact icon={ListChecks} title={filter === "all" ? emptyTitle : filter === "open" ? "Nothing left open" : "No completed tasks yet"} description={filter === "all" && onAdd ? "Add something when you're ready." : undefined} />
      )}
      {onAdd && (filter !== "completed" || !filterable) && <button className="inline-add" onClick={onAdd}><Plus size={16} /> Add a task</button>}
    </div>
  );
}