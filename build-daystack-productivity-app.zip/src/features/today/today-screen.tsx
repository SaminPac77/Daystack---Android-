import { CalendarDays, CircleAlert, Plus } from "lucide-react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { useClock } from "@/app/hooks";
import { usePreferences } from "@/app/preferences";
import { dayKey, greeting, readableDate } from "@/domain/dates";
import { getToday, prioritySlots } from "@/domain/today";
import { TaskList } from "@/features/tasks/task-list";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingState } from "@/components/states";
import { PrioritySection } from "./priority-section";
import { TodayContext } from "./today-context";

export function TodayScreen() {
  const { scope, data, loading, problem, reload } = useWorkspace();
  const capture = useUi((state) => state.setCapture);
  const name = usePreferences((state) => state.names[scope]);
  const now = useClock();
  const today = dayKey(now);
  const titleName = scope === "demo" ? "Alex" : name?.split(/\s+/)[0];
  const snapshot = getToday(data.tasks, today);
  const slots = prioritySlots(data.tasks, snapshot.today, data.plans.find(({ day }) => day === today));
  const add = () => capture({ type: "task", due: today });
  return (
    <div className="surface-container today-page">
      <section className="today-hero" aria-labelledby="greeting-heading">
        <div className="hero-art" aria-hidden="true" />
        <div className="hero-copy">
          <div className="hero-date"><CalendarDays size={15} strokeWidth={1.8} /><time dateTime={today}>{readableDate(now, { weekday: "long", month: "long", day: "numeric" })}</time></div>
          <h1 id="greeting-heading">{greeting(now)}{titleName ? `, ${titleName}.` : "."}</h1>
          <p>Here's what's on your stack today.</p>
        </div>
      </section>
      {loading ? <LoadingState /> : problem ? <div className="mt-6"><ErrorState retry={reload} /></div> : (
        <div className="today-grid">
          <div className="today-primary">
            <PrioritySection key={`${scope}-${today}`} slots={slots} day={today} />
            <section aria-labelledby="today-tasks-heading" className="today-tasks">
              <div className="section-heading"><div className="today-task-heading"><h2 id="today-tasks-heading">Today's tasks</h2>{snapshot.overdue.length > 0 && <a href="#overdue-heading" className="overdue-link">{snapshot.overdue.length} overdue</a>}</div><Button size="sm" variant="outline" onClick={add}><Plus size={16} /> Add task</Button></div>
              <TaskList tasks={snapshot.today} filterable onAdd={add} emptyTitle="Nothing on your stack yet" />
            </section>
            {snapshot.overdue.length > 0 && <section aria-labelledby="overdue-heading">
              <div className="section-heading"><h2 className="overdue-title" id="overdue-heading" tabIndex={-1}><CircleAlert size={19} /> Overdue <span>{snapshot.overdue.length}</span></h2></div>
              <TaskList tasks={snapshot.overdue} showDue />
            </section>}
          </div>
          <TodayContext completed={snapshot.completed} total={snapshot.today.length} percent={snapshot.percent} upcoming={snapshot.upcoming} />
        </div>
      )}
    </div>
  );
}