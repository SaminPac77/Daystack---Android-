import { ArrowRight, ArrowUpRight, CalendarDays, ChartNoAxesColumnIncreasing, Timer } from "lucide-react";
import { Link } from "react-router-dom";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { ProgressIndicator } from "@/components/progress-indicator";
import { Button } from "@/components/ui/button";
import { readableDate } from "@/domain/dates";
import type { Task } from "@/domain/models";

function DailyProgress({ completed, total, percent }: { completed: number; total: number; percent: number }) {
  const remaining = total - completed;
  return <section className="panel daily-progress" aria-labelledby="daily-progress-heading">
    <div className="context-heading"><span className="context-icon progress-icon"><ChartNoAxesColumnIncreasing size={18} strokeWidth={1.9} /></span><div><h2 id="daily-progress-heading">Daily progress</h2><p>Small steps add up.</p></div></div>
    <div className="progress-summary">
      <ProgressIndicator circular value={percent} label="Today's completion progress" />
      <div><strong>{completed} of {total} tasks</strong><span>complete</span><p>{remaining > 0 ? `${remaining} ${remaining === 1 ? "task" : "tasks"} remaining` : total ? "All caught up" : "Ready when you are"}</p></div>
    </div>
  </section>;
}

function FocusShortcut() {
  return <section className="focus-shortcut" aria-labelledby="focus-shortcut-heading">
    <div className="context-heading"><span className="context-icon focus-icon"><Timer size={19} strokeWidth={1.9} /></span><div><h2 id="focus-shortcut-heading">Focus mode</h2><p>One thing at a time.</p></div></div>
    <Button asChild className="focus-shortcut-button" size="sm"><Link to="/focus">Start a focus session <ArrowRight size={16} /></Link></Button>
  </section>;
}

function UpcomingDeadlines({ tasks }: { tasks: Task[] }) {
  const { data } = useWorkspace();
  const capture = useUi((state) => state.setCapture);
  return <section className="panel upcoming-panel" aria-labelledby="upcoming-heading">
    <div className="upcoming-heading"><h2 id="upcoming-heading">Upcoming</h2><Link to="/plan" className="inline-link">View plan <ArrowUpRight size={14} /></Link></div>
    {tasks.length ? <ul className="deadline-list">
      {tasks.slice(0, 3).map((task) => {
        const project = data.projects.find((item) => item.id === task.projectId);
        const due = task.dueAt!;
        return <li key={task.id}><button className="deadline-row" onClick={() => capture({ type: "task", id: task.id })}>
          <time className="deadline-date" dateTime={due}><span>{readableDate(due, { month: "short" })}</span><strong>{readableDate(due, { day: "numeric" })}</strong></time>
          <span className="deadline-title"><strong>{task.title}</strong><small>{project?.name ?? "No project"}</small></span><ArrowUpRight size={15} className="deadline-arrow" />
        </button></li>;
      })}
    </ul> : <div className="upcoming-empty"><CalendarDays size={17} /><span>No upcoming deadlines.</span></div>}
  </section>;
}

export function TodayContext({ completed, total, percent, upcoming }: { completed: number; total: number; percent: number; upcoming: Task[] }) {
  return <aside className="today-context" aria-label="Day overview"><DailyProgress completed={completed} total={total} percent={percent} /><FocusShortcut /><UpcomingDeadlines tasks={upcoming} /></aside>;
}