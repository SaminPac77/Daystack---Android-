import { Check, ChevronRight, Plus, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { saveDayPlan } from "@/data/workspace-repository";
import type { DayPlan } from "@/domain/models";
import { PriorityBadge, ProjectLabel } from "@/features/tasks/task-card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";

function PriorityEditor({ day, initial, close }: { day: string; initial: DayPlan["slots"]; close: () => void }) {
  const { scope, data } = useWorkspace();
  const notify = useUi((state) => state.notify);
  const [slots, setSlots] = useState(initial);
  const [problem, setProblem] = useState("");
  const [busy, setBusy] = useState(false);
  const options = data.tasks.filter((task) => task.status === "open" || initial.includes(task.id));
  return <Dialog open onOpenChange={(open) => { if (!open && !busy) close(); }}>
    <DialogContent>
      <span className="modal-icon"><SlidersHorizontal size={20} /></span>
      <DialogTitle>Edit today's priorities</DialogTitle>
      <DialogDescription>Choose up to three tasks to make time for today.</DialogDescription>
      <form className="dialog-form" onSubmit={async (event) => {
        event.preventDefault(); setBusy(true); setProblem("");
        try { await saveDayPlan(scope, day, slots); notify("Today's priorities updated."); close(); }
        catch (error) { setProblem(error instanceof Error ? error.message : "Couldn't save the priorities."); }
        finally { setBusy(false); }
      }}>
        {slots.map((id, index) => <label className="field" key={index}><span>Priority {index + 1}</span><select className="form-control" value={id ?? ""} data-initial-focus={index === 0 || undefined} onChange={(event) => {
          const value = event.target.value;
          setSlots((previous) => { const next = [...previous] as DayPlan["slots"]; next[index] = value || null; return next; });
        }}><option value="">Leave empty</option>{options.map((task) => <option key={task.id} value={task.id} disabled={slots.includes(task.id) && task.id !== id}>{task.title}</option>)}</select></label>)}
        {options.length === 0 && <p className="field-hint">Capture a task first, then choose it here.</p>}
        {problem && <p role="alert" className="form-error">{problem}</p>}
        <div className="dialog-actions"><Button variant="outline" onClick={close} disabled={busy}>Cancel</Button><Button type="submit" disabled={busy}>{busy ? "Saving..." : "Save priorities"}</Button></div>
      </form>
    </DialogContent>
  </Dialog>;
}

export function PrioritySection({ day, slots }: { day: string; slots: DayPlan["slots"] }) {
  const { data } = useWorkspace();
  const capture = useUi((state) => state.setCapture);
  const [editing, setEditing] = useState(false);
  return (
    <section aria-labelledby="priority-heading">
      <div className="section-heading priority-heading">
        <div><h2 id="priority-heading">Top priorities</h2><p>Make time for what matters most.</p></div>
        <Button variant="outline" size="sm" onClick={() => setEditing(true)}><SlidersHorizontal size={14} /> <span>Edit priorities</span></Button>
      </div>
      <ol className="panel priorities-panel">
        {slots.map((id, index) => {
          const task = data.tasks.find((item) => item.id === id);
          const project = data.projects.find((item) => item.id === task?.projectId);
          return <li key={index}>
            <button className={`priority-row${!task ? " priority-empty" : ""}`} onClick={task ? () => capture({ type: "task", id: task.id }) : () => setEditing(true)}>
              <span className="priority-number">{task?.status === "completed" ? <Check size={17} /> : `0${index + 1}`}</span>
              <span className="priority-text"><strong>{task?.title ?? `Set priority ${index + 1}`}</strong>{project && <ProjectLabel project={project} />}</span>
              {task ? <><PriorityBadge priority={task.priority} /><ChevronRight className="priority-chevron" size={17} /></> : <Plus className="priority-chevron" size={17} />}
            </button>
          </li>;
        })}
      </ol>
      {editing && <PriorityEditor day={day} initial={slots} close={() => setEditing(false)} />}
    </section>
  );
}