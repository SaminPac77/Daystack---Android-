import { CalendarDays, Plus } from "lucide-react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { useClock } from "@/app/hooks";
import { PageHeading } from "@/components/page-heading";
import { Button } from "@/components/ui/button";
import { TaskList } from "@/features/tasks/task-list";
import { dayKey, readableDate } from "@/domain/dates";
import { getToday } from "@/domain/today";
import type { Task } from "@/domain/models";

export function PlanScreen() {
  const { data } = useWorkspace();
  const capture = useUi((state) => state.setCapture);
  const now = useClock();
  const key = dayKey(now);
  const { today, overdue, upcoming } = getToday(data.tasks, key);
  const unscheduled = data.tasks.filter((task) => !task.dueAt && task.status === "open");
  const days = new Map<string, Task[]>();
  for (const task of upcoming) {
    if (!task.dueAt) continue;
    const date = dayKey(task.dueAt);
    days.set(date, [...(days.get(date) ?? []), task]);
  }
  return <div className="surface-container feature-page agenda-page">
    <PageHeading eyebrow="Agenda" title="Plan" description="See what needs time now, and what's coming next." action={<Button onClick={() => capture({ type: "task" })}><Plus size={18} /> Add task</Button>} />
    <div className="agenda-list">
      {overdue.length > 0 && <section><div className="section-heading"><h2 className="danger-text">Overdue</h2></div><TaskList tasks={overdue} showDue /></section>}
      <section><div className="section-heading"><h2>Today</h2><span className="muted-text"><CalendarDays size={15} />{readableDate(now, { month: "short", day: "numeric" })}</span></div><TaskList tasks={today} onAdd={() => capture({ type: "task", due: key })} emptyTitle="No tasks for today" /></section>
      <section><div className="section-heading"><h2>Upcoming deadlines</h2></div>{days.size ? <div className="agenda-days">{[...days].map(([day, tasks]) => <div key={day}><h3>{readableDate(tasks[0].dueAt!, { weekday: "short", month: "short", day: "numeric" })}</h3><TaskList tasks={tasks} onAdd={() => capture({ type: "task", due: day })} /></div>)}</div> : <TaskList tasks={[]} emptyTitle="No upcoming deadlines" />}</section>
      <section><div className="section-heading"><h2>Unscheduled</h2></div><TaskList tasks={unscheduled} emptyTitle="No unscheduled tasks" /></section>
    </div>
  </div>;
}