import { zodResolver } from "@hookform/resolvers/zod";
import { FolderPlus } from "lucide-react";
import { useForm } from "react-hook-form";
import { useQueryClient } from "@tanstack/react-query";
import { useUi } from "@/app/ui-store";
import { useWorkspace, workspaceKey } from "@/app/workspace-context";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { saveProject } from "@/data/workspace-repository";
import { projectFields, type ProjectFields } from "@/domain/validation";
import type { Project } from "@/domain/models";

export function ProjectEditor({ project, close, saved }: { project?: Project; close: () => void; saved?: (project: Project) => void }) {
  const { scope } = useWorkspace();
  const cache = useQueryClient();
  const notify = useUi((state) => state.notify);
  const { handleSubmit, register, setError, formState: { errors, isSubmitting } } = useForm<ProjectFields>({ resolver: zodResolver(projectFields), defaultValues: { name: project?.name ?? "", description: project?.description ?? "", tone: project?.tone ?? "violet" } });
  return <Dialog open onOpenChange={(open) => { if (!open && !isSubmitting) close(); }}>
    <DialogContent>
      <span className="modal-icon"><FolderPlus size={21} /></span>
      <DialogTitle>{project ? "Edit project" : "New project"}</DialogTitle>
      <DialogDescription>Keep the tasks and notes for one goal together.</DialogDescription>
      <form className="dialog-form" noValidate onSubmit={handleSubmit(async (values) => {
        try {
          const record = await saveProject(scope, values, project?.id);
          await cache.invalidateQueries({ queryKey: workspaceKey(scope) });
          notify(project ? "Project updated." : "Project created."); close(); saved?.(record);
        } catch { setError("root", { message: "Couldn't save the project. Try again." }); }
      })}>
        <label className="field"><span>Project name</span><input className="form-control" data-initial-focus placeholder="e.g. Portfolio refresh" maxLength={100} {...register("name")} />{errors.name && <small className="form-error">{errors.name.message}</small>}</label>
        <label className="field"><span>Description <span className="optional">optional</span></span><textarea className="form-control" placeholder="What is this project about?" rows={4} maxLength={2000} {...register("description")} /></label>
        <label className="field"><span>Project color</span><select className="form-control" {...register("tone")}><option value="violet">Lavender</option><option value="sky">Sky</option><option value="amber">Gold</option><option value="sage">Sage</option></select></label>
        {errors.root && <p className="form-error" role="alert">{errors.root.message}</p>}
        <div className="dialog-actions"><Button variant="outline" onClick={close} disabled={isSubmitting}>Cancel</Button><Button type="submit" disabled={isSubmitting}>{isSubmitting ? "Saving..." : project ? "Save changes" : "Create project"}</Button></div>
      </form>
    </DialogContent>
  </Dialog>;
}