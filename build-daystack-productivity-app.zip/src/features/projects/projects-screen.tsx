import { Archive, ArchiveRestore, ArrowLeft, ArrowUpRight, FolderOpen, Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useUi } from "@/app/ui-store";
import { useWorkspace, workspaceKey } from "@/app/workspace-context";
import { Button } from "@/components/ui/button";
import { PageHeading } from "@/components/page-heading";
import { EmptyState } from "@/components/states";
import { ProgressIndicator } from "@/components/progress-indicator";
import { archiveProject } from "@/data/workspace-repository";
import type { Project, Task } from "@/domain/models";
import { TaskList } from "@/features/tasks/task-list";
import { NoteList } from "@/features/notes/note-list";
import { ProjectEditor } from "./project-editor";

const projectProgress = (tasks: Task[]) => {
  const done = tasks.filter((item) => item.status === "completed").length;
  return { done, percent: tasks.length ? 100 * done / tasks.length : 0 };
};

export function ProjectCard({ project, tasks }: { project: Project; tasks: Task[] }) {
  const { done, percent } = projectProgress(tasks);
  return <Link to={`/projects/${project.id}`} className="panel project-card">
    <div className="project-card-top"><span className={`project-icon tone-${project.tone}`}><FolderOpen size={21} /></span><ArrowUpRight size={17} /></div>
    <h2>{project.name}</h2><p>{project.description || "No description"}</p>
    <div className="project-card-progress"><span>{done} of {tasks.length} tasks complete</span><ProgressIndicator value={percent} label={`${project.name} progress`} /></div>
  </Link>;
}

export function ProjectsScreen() {
  const { data } = useWorkspace();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [archived, setArchived] = useState(false);
  const records = data.projects.filter((item) => item.status === (archived ? "archived" : "active")).sort((a, b) => a.name.localeCompare(b.name));
  return <div className="surface-container feature-page">
    <PageHeading title="Projects" description="Keep related work in one place." action={<Button onClick={() => setEditing(true)}><Plus size={18} /> New project</Button>} />
    <div className="record-filter" role="group" aria-label="Project filter"><button onClick={() => setArchived(false)} aria-pressed={!archived}>Active</button><button onClick={() => setArchived(true)} aria-pressed={archived}>Archived</button></div>
    {records.length ? <div className="project-grid">{records.map((project) => <ProjectCard key={project.id} project={project} tasks={data.tasks.filter((task) => task.projectId === project.id)} />)}</div> : <div className="panel"><EmptyState icon={FolderOpen} title={archived ? "No archived projects" : "Start with one project"} description={archived ? "Archived projects stay here until you restore or delete them." : "Create a project when you have tasks or notes that belong together."} action={!archived ? <Button variant="outline" onClick={() => setEditing(true)}><Plus size={16} /> New project</Button> : undefined} /></div>}
    {editing && <ProjectEditor close={() => setEditing(false)} saved={(record) => navigate(`/projects/${record.id}`)} />}
  </div>;
}

export function ProjectDetailsScreen() {
  const { id } = useParams();
  const { scope, data } = useWorkspace();
  const cache = useQueryClient();
  const notify = useUi((state) => state.notify);
  const capture = useUi((state) => state.setCapture);
  const deleteItem = useUi((state) => state.setDeletion);
  const [editing, setEditing] = useState(false);
  const project = data.projects.find((record) => record.id === id);
  const archive = useMutation({ networkMode: "always", mutationFn: (item: Project) => archiveProject(scope, item.id, item.status !== "archived"),
    onSuccess: (_value, item) => notify(item.status === "archived" ? "Project restored." : "Project archived."),
    onError: () => notify("Couldn't update the project.", "error"), onSettled: () => cache.invalidateQueries({ queryKey: workspaceKey(scope) }) });
  if (!project) return <div className="surface-container"><div className="panel"><EmptyState icon={FolderOpen} title="Project not found" description="It might have been removed or belongs to another workspace." action={<Button asChild variant="outline"><Link to="/projects">Back to projects</Link></Button>} /></div></div>;
  const tasks = data.tasks.filter((task) => task.projectId === project.id);
  const notes = data.notes.filter((note) => note.projectId === project.id);
  const { done, percent } = projectProgress(tasks);
  const archived = project.status === "archived";
  return <div className="surface-container feature-page">
    <Link className="inline-link back-link" to="/projects"><ArrowLeft size={15} /> All projects</Link>
    <PageHeading eyebrow={archived ? "Archived project" : "Active project"} title={project.name} description={project.description || "No project description yet."} action={<Button variant="outline" onClick={() => setEditing(true)}><Pencil size={16} /> Edit project</Button>} />
    <section className="panel project-detail-summary" aria-label="Project progress and actions">
      <div><strong>{done} of {tasks.length} tasks completed</strong><ProgressIndicator value={percent} label="Project completion progress" /></div>
      <div className="project-detail-actions"><Button variant="ghost" size="sm" onClick={() => archive.mutate(project)} disabled={archive.isPending}>{archived ? <ArchiveRestore size={16} /> : <Archive size={16} />}{archived ? "Restore" : "Archive"}</Button><Button variant="ghost" size="sm" className="danger-text" onClick={() => deleteItem({ kind: "project", id: project.id, title: project.name })}><Trash2 size={16} /> Delete</Button></div>
    </section>
    <section className="feature-section"><div className="section-heading"><h2>Project tasks</h2>{!archived && <Button size="sm" variant="outline" onClick={() => capture({ type: "task", projectId: project.id })}><Plus size={16} /> Add task</Button>}</div><TaskList tasks={tasks} showDue filterable onAdd={!archived ? () => capture({ type: "task", projectId: project.id }) : undefined} /></section>
    <section className="feature-section"><div className="section-heading"><h2>Project notes</h2>{!archived && <Button size="sm" variant="outline" onClick={() => capture({ type: "note", projectId: project.id })}><Plus size={16} /> Add note</Button>}</div><NoteList notes={notes} /></section>
    {editing && <ProjectEditor project={project} close={() => setEditing(false)} />}
  </div>;
}