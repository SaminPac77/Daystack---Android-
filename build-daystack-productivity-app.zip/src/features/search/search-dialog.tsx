import { ArrowUpRight, FileText, FolderOpen, ListTodo, Search } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";

export function SearchDialog() {
  const { data } = useWorkspace();
  const navigate = useNavigate();
  const dismiss = useUi((state) => state.setSearch);
  const capture = useUi((state) => state.setCapture);
  const [text, setText] = useState("");
  const query = text.trim().toLowerCase();
  const results = query ? [
    ...data.tasks.filter((task) => `${task.title} ${task.description}`.toLowerCase().includes(query)).map((task) => ({ id: task.id, title: task.title, type: "task" as const, icon: ListTodo })),
    ...data.notes.filter((note) => `${note.title} ${note.body}`.toLowerCase().includes(query)).map((note) => ({ id: note.id, title: note.title, type: "note" as const, icon: FileText })),
    ...data.projects.filter((project) => `${project.name} ${project.description}`.toLowerCase().includes(query)).map((project) => ({ id: project.id, title: project.name, type: "project" as const, icon: FolderOpen })),
  ].slice(0, 20) : [];
  const choose = (result: typeof results[number]) => {
    dismiss(false);
    if (result.type === "project") navigate(`/projects/${result.id}`);
    else capture({ type: result.type, id: result.id });
  };

  return <Dialog open onOpenChange={(open) => { if (!open) dismiss(false); }}>
    <DialogContent className="search-dialog">
      <DialogTitle>Search workspace</DialogTitle>
      <DialogDescription>Find a task, note, or project in this workspace.</DialogDescription>
      <form className="dialog-search-form" onSubmit={(event) => { event.preventDefault(); if (results[0]) choose(results[0]); }}>
        <Search size={19} /><input type="search" value={text} onChange={(event) => setText(event.target.value)} data-initial-focus aria-label="Search tasks, notes, and projects" placeholder="Type to search..." />
      </form>
      {results.length > 0 ? <ul className="search-results">{results.map(({ icon: Icon, ...item }) => <li key={item.id}><button onClick={() => choose({ ...item, icon: Icon })}><Icon size={17} /><span>{item.title}<small>{item.type}</small></span><ArrowUpRight size={15} /></button></li>)}</ul> : <p className="search-empty" role="status">{query ? "No matches. Try a different search." : "Search by title or by words you've written."}</p>}
    </DialogContent>
  </Dialog>;
}