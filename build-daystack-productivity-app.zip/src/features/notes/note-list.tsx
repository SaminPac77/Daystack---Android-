import { Ellipsis, FileText, Pencil, Trash2 } from "lucide-react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Dropdown, DropdownContent, DropdownItem, DropdownTrigger } from "@/components/ui/dropdown";
import { readableDate } from "@/domain/dates";
import { ProjectLabel } from "@/features/tasks/task-card";
import type { Note } from "@/domain/models";

function inlineFormat(value: string) {
  return value.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((part, index) => part.startsWith("**") && part.endsWith("**") ? <strong key={index}>{part.slice(2, -2)}</strong> : part.startsWith("*") && part.endsWith("*") && part.length > 2 ? <em key={index}>{part.slice(1, -1)}</em> : part);
}

function NotePreview({ body }: { body: string }) {
  return <div className="note-preview">{body.split("\n").slice(0, 6).map((line, index) => line.startsWith("- ") ? <p className="note-bullet" key={index}>{inlineFormat(line.slice(2))}</p> : <p key={index}>{inlineFormat(line) || " "}</p>)}</div>;
}

export function NoteList({ notes, filtered }: { notes: Note[]; filtered?: boolean }) {
  const { data } = useWorkspace();
  const open = useUi((state) => state.setCapture);
  const remove = useUi((state) => state.setDeletion);
  if (!notes.length) return <div className="panel"><EmptyState icon={FileText} title={filtered ? "No matching notes" : "No notes yet"} description={filtered ? "Try a different search." : "Capture an idea, a checklist, or something you want to remember."} /></div>;
  return <div className="note-grid">{notes.slice().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).map((note) => {
    const project = data.projects.find((item) => item.id === note.projectId);
    const edit = () => open({ type: "note", id: note.id });
    return <article key={note.id} className="panel note-card">
      <div className="note-card-top"><span className="project-icon tone-amber"><FileText size={19} /></span><Dropdown modal={false}><DropdownTrigger asChild><Button variant="ghost" size="icon" aria-label={`Actions for ${note.title}`}><Ellipsis size={18} /></Button></DropdownTrigger><DropdownContent align="end"><DropdownItem onSelect={edit}><Pencil size={15} /> Edit note</DropdownItem><DropdownItem className="danger-text" onSelect={() => remove({ kind: "note", id: note.id, title: note.title })}><Trash2 size={15} /> Delete note</DropdownItem></DropdownContent></Dropdown></div>
      <h2><button className="note-title" onClick={edit}>{note.title}</button></h2>
      <NotePreview body={note.body || "No note text"} />
      <div className="note-meta">{project && <ProjectLabel project={project} />}<time dateTime={note.updatedAt}>{readableDate(note.updatedAt, { month: "short", day: "numeric" })}</time></div>
    </article>;
  })}</div>;
}