import { Plus, Search } from "lucide-react";
import { useState } from "react";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { PageHeading } from "@/components/page-heading";
import { Button } from "@/components/ui/button";
import { NoteList } from "./note-list";

export function NotesScreen() {
  const { data } = useWorkspace();
  const open = useUi((state) => state.setCapture);
  const [search, setSearch] = useState("");
  const query = search.trim().toLowerCase();
  const notes = data.notes.filter((item) => `${item.title} ${item.body}`.toLowerCase().includes(query));
  return <div className="surface-container feature-page">
    <PageHeading title="Notes" description="A place for the things you want to keep." action={<Button onClick={() => open({ type: "note" })}><Plus size={18} /> New note</Button>} />
    <label className="record-search"><Search size={17} /><input type="search" aria-label="Search notes" placeholder="Search notes..." value={search} onChange={(event) => setSearch(event.target.value)} /></label>
    <NoteList notes={notes} filtered={Boolean(query)} />
  </div>;
}