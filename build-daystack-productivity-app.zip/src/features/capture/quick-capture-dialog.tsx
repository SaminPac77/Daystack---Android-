import { zodResolver } from "@hookform/resolvers/zod";
import { Bold, FileText, Italic, List, ListTodo, Plus, Zap } from "lucide-react";
import { useRef } from "react";
import { useForm } from "react-hook-form";
import { useQueryClient } from "@tanstack/react-query";
import { useUi, type CaptureRequest } from "@/app/ui-store";
import { useWorkspace, workspaceKey } from "@/app/workspace-context";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { dateToTimestamp, dayKey } from "@/domain/dates";
import { captureSchema, type CaptureValues } from "@/domain/validation";
import { saveNote, saveTask } from "@/data/workspace-repository";

export function QuickCaptureDialog({ request }: { request: CaptureRequest }) {
  const { scope, data } = useWorkspace();
  const close = useUi((state) => state.setCapture);
  const notify = useUi((state) => state.notify);
  const cache = useQueryClient();
  const task = request.id && request.type === "task" ? data.tasks.find(({ id }) => id === request.id) : undefined;
  const note = request.id && request.type === "note" ? data.notes.find(({ id }) => id === request.id) : undefined;
  const missing = !!request.id && !(task || note);
  const form = useForm<CaptureValues>({ resolver: zodResolver(captureSchema), defaultValues: {
    type: request.type, title: task?.title ?? note?.title ?? "", description: task?.description ?? note?.body ?? "",
    priority: task?.priority ?? "none", due: task?.dueAt ? dayKey(task.dueAt) : request.due ?? "",
    project: task?.projectId ?? note?.projectId ?? request.projectId ?? "",
  } });
  const type = form.watch("type");
  const selectedProject = form.watch("project");
  const busy = form.formState.isSubmitting;
  const errors = form.formState.errors;
  const description = form.register("description");
  const textarea = useRef<HTMLTextAreaElement | null>(null);

  function format(prefix: string, suffix = "") {
    const input = textarea.current;
    if (!input) return;
    const { value, selectionStart: start, selectionEnd: end } = input;
    let replacement: string;
    if (suffix) replacement = `${prefix}${value.slice(start, end) || "text"}${suffix}`;
    else replacement = `${start > 0 && value[start - 1] !== "\n" ? "\n" : ""}- ${value.slice(start, end)}`;
    form.setValue("description", value.slice(0, start) + replacement + value.slice(end), { shouldDirty: true });
    requestAnimationFrame(() => { input.focus(); input.setSelectionRange(start + replacement.length, start + replacement.length); });
  }

  const submit = form.handleSubmit(async (values) => {
    form.clearErrors("root");
    try {
      const projectId = values.project || null;
      if (values.type === "note") await saveNote(scope, { title: values.title, body: values.description, projectId }, request.id);
      else await saveTask(scope, { title: values.title, description: values.description, priority: values.priority, dueAt: dateToTimestamp(values.due), projectId }, request.id);
      await cache.invalidateQueries({ queryKey: workspaceKey(scope) });
      notify(`${values.type === "note" ? "Note" : "Task"} ${request.id ? "updated" : "added"}.`);
      close(null);
    } catch (error) {
      form.setError("root", { message: error instanceof Error && error.name === "Error" ? error.message : "Couldn't save this item on your device. Try again." });
    }
  });

  return (
    <Dialog open onOpenChange={(open) => { if (!open && !busy) close(null); }}>
      <DialogContent className="capture-dialog">
        <span className="modal-icon"><Zap size={20} strokeWidth={1.9} /></span>
        <DialogTitle>{missing ? "Item not found" : request.id ? `Edit ${type}` : "Quick Capture"}</DialogTitle>
        <DialogDescription>{missing ? "It might have been removed in another tab." : request.id ? "Changes are saved on this device first." : "Get it out of your head and onto your stack."}</DialogDescription>
        {!missing && <form className="dialog-form" noValidate onSubmit={submit}>
          {!request.id && <div className="segmented" role="group" aria-label="Capture type">
            <button type="button" aria-pressed={type === "task"} onClick={() => form.setValue("type", "task")}><ListTodo size={16} /> Task</button>
            <button type="button" aria-pressed={type === "note"} onClick={() => form.setValue("type", "note")}><FileText size={16} /> Note</button>
          </div>}
          <label className="field"><span>Title</span><input className="form-control" placeholder={type === "task" ? "What needs doing?" : "Give your note a title"} maxLength={160} autoComplete="off" data-initial-focus aria-invalid={!!errors.title} {...form.register("title")} />{errors.title && <small className="form-error">{errors.title.message}</small>}</label>
          <div className="field">
            <label htmlFor="capture-description">{type === "note" ? "Note" : "Description"} <span className="optional">optional</span></label>
            {type === "note" && <div className="format-toolbar" role="toolbar" aria-label="Note formatting">
              <Button size="icon" variant="ghost" title="Bold" aria-label="Bold" onClick={() => format("**", "**")}><Bold size={15} /></Button>
              <Button size="icon" variant="ghost" title="Italic" aria-label="Italic" onClick={() => format("*", "*")}><Italic size={15} /></Button>
              <Button size="icon" variant="ghost" title="Bulleted list" aria-label="Bulleted list" onClick={() => format("-")}><List size={16} /></Button>
            </div>}
            <textarea id="capture-description" className="form-control" rows={type === "note" ? 5 : 3} maxLength={6000} placeholder={type === "note" ? "Write something to remember..." : "Add a little detail..."} {...description} ref={(element) => { textarea.current = element; description.ref(element); }} />
            {errors.description && <small className="form-error">{errors.description.message}</small>}
          </div>
          {type === "task" && <div className="field-grid">
            <label className="field"><span>Priority</span><select className="form-control" {...form.register("priority")}><option value="none">No priority</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
            <label className="field"><span>Due date <span className="optional">optional</span></span><input className="form-control" type="date" {...form.register("due")} />{errors.due && <small className="form-error">{errors.due.message}</small>}</label>
          </div>}
          <label className="field"><span>Project <span className="optional">optional</span></span><select className="form-control" {...form.register("project")}><option value="">No project</option>{data.projects.filter((project) => project.status === "active" || project.id === selectedProject).map((project) => <option key={project.id} value={project.id}>{project.name}{project.status === "archived" ? " (archived)" : ""}</option>)}</select></label>
          {errors.root && <p className="form-error" role="alert">{errors.root.message}</p>}
          <div className="dialog-actions"><Button variant="outline" onClick={() => close(null)} disabled={busy}>Cancel</Button><Button type="submit" disabled={busy}>{!request.id && <Plus size={16} />}{busy ? "Saving..." : request.id ? "Save changes" : `Add ${type}`}</Button></div>
        </form>}
      </DialogContent>
    </Dialog>
  );
}