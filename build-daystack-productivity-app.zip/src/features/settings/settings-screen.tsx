import { ArrowUpRight, Check, Cloud, CloudOff, Download, FlaskConical, HardDrive, LogIn, LogOut, Monitor, Moon, RefreshCw, ShieldCheck, Sun } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/app/auth-context";
import { usePreferences, type Theme } from "@/app/preferences";
import { useUi } from "@/app/ui-store";
import { useWorkspace } from "@/app/workspace-context";
import { useSwitchWorkspace } from "@/components/layout/workspace-menu";
import { PageHeading } from "@/components/page-heading";
import { Button } from "@/components/ui/button";
import { navigation } from "@/components/layout/navigation";
import { signOutThisDevice } from "@/data/auth-repository";
import { platform } from "@/platform/platform";

const appearances: { theme: Theme; label: string; icon: typeof Sun }[] = [{ theme: "light", label: "Light", icon: Sun }, { theme: "dark", label: "Dark", icon: Moon }, { theme: "system", label: "System", icon: Monitor }];

function SettingSection({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return <section className="panel setting-section"><h2>{title}</h2>{description && <p>{description}</p>}{children}</section>;
}

function ProfileForm() {
  const { scope } = useWorkspace();
  const value = usePreferences((state) => state.names[scope]) ?? "";
  const setName = usePreferences((state) => state.setName);
  const notify = useUi((state) => state.notify);
  const [name, setDisplayName] = useState(value);
  return <form className="profile-form" onSubmit={(event) => { event.preventDefault(); setName(scope, name); setDisplayName(name.trim()); notify("Profile saved on this device."); }}><label className="field"><span>Display name</span><input className="form-control" placeholder="Your name" autoComplete="name" maxLength={60} value={name} onChange={(event) => setDisplayName(event.target.value)} /></label><Button type="submit" variant="outline">Save profile</Button></form>;
}

export function SettingsScreen() {
  const { data, scope, online, sync, syncNow, problem, loading } = useWorkspace();
  const { session, configured } = useAuth();
  const { theme, setTheme, notifications, setNotifications } = usePreferences();
  const signIn = useUi((state) => state.setAuthentication);
  const notify = useUi((state) => state.notify);
  const changeWorkspace = useSwitchWorkspace();
  const [working, setWorking] = useState(false);
  const demo = scope === "demo";
  const cloud = scope.startsWith("account:");
  const status = !online ? "Offline" : sync === "syncing" ? "Syncing" : sync === "error" ? "Waiting to retry" : data.pending ? "Changes pending upload" : cloud ? sync === "ready" ? "Up to date" : "Checking for changes" : "On this device only";

  return <div className="surface-container feature-page settings-page">
    <PageHeading title="Settings" description="Make DAYSTACK work the way you do." />
    <nav className="mobile-tools" aria-label="Other workspace tools">
      {navigation.slice(4).map(({ label, path, icon: Icon }) => <Link to={path} key={path}><Icon size={16} /><span>{label}</span><ArrowUpRight size={13} /></Link>)}
    </nav>
    <div className="settings-grid">
      <SettingSection title="Workspace" description={demo ? "You're exploring a demo with example tasks, projects, and notes. Switch to your own empty workspace whenever you're ready." : "Workspaces are kept separate. Your personal workspace stays on this device."}>
        <div className="settings-actions">
          {scope !== "local" && <Button onClick={() => changeWorkspace("local")}><HardDrive size={16} /> Use my workspace</Button>}
          {!demo && <Button variant="outline" onClick={() => changeWorkspace("demo")}><FlaskConical size={16} /> Demo workspace</Button>}
          {session && !cloud && <Button variant="outline" onClick={() => changeWorkspace("account")}><Cloud size={16} /> Cloud workspace</Button>}
        </div>
      </SettingSection>
      <SettingSection title="Appearance" description="Choose the theme that's easiest on your eyes.">
        <div className="theme-options" role="group" aria-label="Appearance">{appearances.map(({ theme: value, label, icon: Icon }) => <button key={value} aria-pressed={value === theme} onClick={() => setTheme(value)}><Icon size={17} />{label}{theme === value && <Check size={14} />}</button>)}</div>
      </SettingSection>
      <SettingSection title="Profile" description={demo ? "The demo uses a sample profile. Switch to your personal workspace to set your name." : "Your display name is stored on this device."}>
        {!demo && <ProfileForm key={scope} />}
        {session && <p className="field-hint account-email">Signed in as {session.user.email}</p>}
      </SettingSection>
      <SettingSection title="Account & sync" description={configured ? "Sign in to sync tasks, projects, and notes in your cloud workspace. Local and demo records are not uploaded." : "No cloud service is configured. An account is not needed to use this device."}>
        <div className="sync-chip" role="status">{online && cloud ? <Cloud size={15} /> : <CloudOff size={15} />}{status}{data.pending > 0 && <span>({data.pending} pending)</span>}</div>
        <div className="settings-actions">
          {session ? <Button variant="outline" disabled={working} onClick={async () => {
            setWorking(true);
            try {
              await signOutThisDevice();
              changeWorkspace("local"); notify("Signed out on this device.");
            } catch { notify("Couldn't sign out. Check your connection and try again.", "error"); } finally { setWorking(false); }
          }}><LogOut size={16} /> Sign out</Button> : <Button variant="outline" onClick={() => signIn(true)}><LogIn size={16} /> Sign in</Button>}
          {cloud && <Button variant="outline" disabled={!online || sync === "syncing"} onClick={syncNow}><RefreshCw size={16} /> Sync now</Button>}
        </div>
      </SettingSection>
      <SettingSection title="Notifications" description="Allow a device notification when the focus timer finishes while DAYSTACK is open.">
        <Button variant="outline" disabled={working} aria-pressed={notifications} onClick={async () => {
          if (notifications) { setNotifications(false); notify("Focus notifications turned off."); return; }
          setWorking(true);
          try {
            if (platform.capabilities().notifications && await platform.allowNotifications()) { setNotifications(true); notify("Focus notifications turned on."); }
            else notify("Notifications aren't allowed on this device.", "info");
          } catch { notify("Notifications aren't available here.", "info"); } finally { setWorking(false); }
        }}>{notifications ? "Turn notifications off" : "Allow focus notifications"}</Button>
      </SettingSection>
      <SettingSection title="Language" description="The interface is currently available in English."><p className="setting-value">English</p></SettingSection>
      <SettingSection title="Backup & privacy" description="Export this workspace as JSON. Local storage is private to this browser profile; clearing site data will remove it.">
        <div className="settings-actions"><Button disabled={loading || problem} variant="outline" onClick={() => {
          try {
            const { tasks, projects, notes, plans } = data;
            platform.download("daystack-backup.json", new Blob([JSON.stringify({ format: "daystack-v1", exportedAt: new Date().toISOString(), tasks, projects, notes, plans }, null, 2)], { type: "application/json" }));
            notify("Workspace exported.");
          } catch { notify("Couldn't export this workspace.", "error"); }
        }}><Download size={16} /> Export data</Button></div>
        <p className="privacy-caption"><ShieldCheck size={15} /> No analytics or tracking in this build.</p>
      </SettingSection>
    </div>
  </div>;
}