import { Coffee, Pause, Play, RotateCcw, Timer } from "lucide-react";
import { useState } from "react";
import { useWorkspace } from "@/app/workspace-context";
import { PageHeading } from "@/components/page-heading";
import { Button } from "@/components/ui/button";
import { ProgressIndicator } from "@/components/progress-indicator";
import { remainingTime, useFocusTimer } from "./focus-timer";

const presets = [15, 25, 45];

export function FocusScreen() {
  const { scope, data } = useWorkspace();
  const { timer, remainingMs, set } = useFocusTimer(scope);
  const running = timer.endsAt !== null;
  const paused = !running && !timer.finished && timer.remainingMs < timer.durationMs && timer.remainingMs > 0;
  const [custom, setCustom] = useState(false);
  const [minutes, setMinutes] = useState("");
  const seconds = Math.ceil(remainingMs / 1000);
  const clock = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const chooseDuration = (value: number) => set({ durationMs: value * 60_000, remainingMs: value * 60_000, finished: false, endsAt: null });
  const activeTasks = data.tasks.filter(({ status }) => status === "open");
  return <div className="surface-container feature-page focus-page">
    <PageHeading title="Focus" description="Set aside a little time for one important thing." />
    <section className="panel timer-panel" aria-labelledby="timer-heading">
      <span className="context-icon focus-icon"><Timer size={22} /></span>
      <h2 id="timer-heading">Focus timer</h2>
      <div className="timer-presets" role="group" aria-label="Timer duration">
        {presets.map((value) => <Button variant="outline" size="sm" key={value} disabled={running || paused} aria-pressed={timer.durationMs / 60_000 === value && !custom} onClick={() => { chooseDuration(value); setCustom(false); }}>{value} min</Button>)}
        <Button variant="outline" size="sm" disabled={running || paused} aria-pressed={custom} onClick={() => setCustom(!custom)}>Custom</Button>
      </div>
      {custom && <form className="timer-custom" onSubmit={(event) => { event.preventDefault(); const value = Number(minutes); if (Number.isInteger(value) && value >= 1 && value <= 180) chooseDuration(value); }}><label className="field"><span>Minutes</span><input className="form-control" type="number" min={1} max={180} required value={minutes} onChange={(event) => setMinutes(event.target.value)} disabled={running || paused} /></label><Button variant="outline" type="submit" disabled={running || paused}>Set duration</Button></form>}
      <div className="timer-clock" role="timer" aria-label={clock}>{clock}</div>
      <div className="timer-progress"><ProgressIndicator value={100 * (1 - remainingMs / timer.durationMs)} label="Focus session progress" /></div>
      {timer.finished && <div className="focus-finished" role="status"><Coffee size={18} /> Session complete. Take a short break.</div>}
      <label className="field timer-task"><span>Focus on a task <span className="optional">optional</span></span><select className="form-control" disabled={running || paused} value={activeTasks.some(({ id }) => id === timer.taskId) ? timer.taskId : ""} onChange={(event) => set({ taskId: event.target.value })}><option value="">No task selected</option>{activeTasks.map((task) => <option key={task.id} value={task.id}>{task.title}</option>)}</select></label>
      <div className="timer-actions">
        <Button className="timer-start" onClick={() => {
          if (running) set({ remainingMs: remainingTime(timer, Date.now()), endsAt: null });
          else set({ endsAt: Date.now() + (timer.remainingMs || timer.durationMs), remainingMs: timer.remainingMs || timer.durationMs, finished: false });
        }}>{running ? <Pause size={17} /> : <Play size={17} />}{running ? "Pause" : paused ? "Resume" : "Start focus"}</Button>
        <Button variant="outline" size="icon" aria-label="Reset timer" title="Reset timer" onClick={() => chooseDuration(timer.durationMs / 60_000)}><RotateCcw size={17} /></Button>
      </div>
    </section>
  </div>;
}