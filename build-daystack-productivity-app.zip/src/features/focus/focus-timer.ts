import { useEffect, useState } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { usePreferences } from "@/app/preferences";
import { useUi } from "@/app/ui-store";
import { platform } from "@/platform/platform";
import type { Scope } from "@/domain/models";

export interface Timer {
  durationMs: number;
  remainingMs: number;
  endsAt: number | null;
  taskId: string;
  finished: boolean;
}

const defaults: Timer = { durationMs: 25 * 60_000, remainingMs: 25 * 60_000, endsAt: null, taskId: "", finished: false };
interface Timers { timers: Partial<Record<Scope, Timer>>; update: (scope: Scope, update: Partial<Timer>) => void }
const useTimers = create<Timers>()(persist((set) => ({
  timers: {},
  update: (scope, updates) => set((state) => ({ timers: { ...state.timers, [scope]: { ...(state.timers[scope] ?? defaults), ...updates } } })),
}), { name: "daystack-focus-timer-v1" }));

export function remainingTime(timer: Timer, now: number) {
  return Math.max(0, timer.endsAt === null ? timer.remainingMs : timer.endsAt - now);
}

export function useFocusTimer(scope: Scope) {
  const timer = useTimers((state) => state.timers[scope]) ?? defaults;
  const update = useTimers((state) => state.update);
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    if (timer.endsAt === null) return;
    const tick = () => setNow(Date.now());
    tick();
    const handle = window.setInterval(tick, 250);
    return () => window.clearInterval(handle);
  }, [timer.endsAt]);
  return { timer, remainingMs: remainingTime(timer, now), set: (updates: Partial<Timer>) => update(scope, updates) };
}

export function useFocusAlarm(scope: Scope) {
  const endsAt = useTimers((state) => state.timers[scope]?.endsAt ?? null);
  useEffect(() => {
    if (endsAt === null) return;
    const finish = () => {
      const current = useTimers.getState().timers[scope];
      if (current?.endsAt !== endsAt || Date.now() < endsAt) return;
      useTimers.getState().update(scope, { endsAt: null, remainingMs: 0, finished: true });
      useUi.getState().notify("Focus session complete.");
      if (usePreferences.getState().notifications) void platform.notify("DAYSTACK", "Your focus session is complete.").catch(() => {});
    };
    const handle = window.setTimeout(finish, Math.max(0, endsAt - Date.now()) + 25);
    const cleanup = platform.onResume(finish);
    return () => { window.clearTimeout(handle); cleanup(); };
  }, [scope, endsAt]);
}