import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { liveQuery } from "dexie";
import { openWorkspace, readWorkspace, workspaceWrites } from "@/data/workspace-repository";
import { supabase } from "@/data/supabase";
import { syncWorkspace } from "@/data/cloud-repository";
import { platform } from "@/platform/platform";
import type { Scope, WorkspaceData } from "@/domain/models";
import { useAuth } from "./auth-context";
import { useOnline } from "./hooks";
import { usePreferences } from "./preferences";

const blank: WorkspaceData = { tasks: [], projects: [], notes: [], plans: [], pending: 0 };
type SyncState = "local" | "preview" | "paused" | "idle" | "syncing" | "error" | "ready";

interface ActiveWorkspace {
  scope: Scope;
  data: WorkspaceData;
  loading: boolean;
  problem: boolean;
  reload: () => void;
  online: boolean;
  sync: SyncState;
  syncNow: () => void;
}

const Context = createContext<ActiveWorkspace | null>(null);
export const workspaceKey = (scope: Scope) => ["workspace", scope] as const;

function useSync(scope: Scope, owner: string | undefined, online: boolean) {
  const [status, setStatus] = useState<SyncState>("idle");
  const [request, setRequest] = useState(0);
  const lastRequest = useRef(0);
  const syncNow = () => setRequest((value) => value + 1);
  const active = !!owner && scope === `account:${owner}`;

  useEffect(() => {
    const client = supabase;
    if (!client || !active || !owner || !online) return;
    const force = request !== lastRequest.current;
    lastRequest.current = request;
    const controller = new AbortController();
    let running = false;
    let again = false;
    const run = async (retryNow = false) => {
      if (controller.signal.aborted) return;
      if (running) { again = true; return; }
      running = true;
      setStatus("syncing");
      try {
        await syncWorkspace(client, owner, controller.signal, retryNow);
        if (!controller.signal.aborted) setStatus("ready");
      } catch {
        if (!controller.signal.aborted) setStatus("error");
      } finally {
        running = false;
        if (again) { again = false; void run(); }
      }
    };
    const refresh = () => { void run(); };
    const timer = window.setInterval(refresh, 25_000);
    const remove = platform.onResume(refresh);
    workspaceWrites.addEventListener("change", refresh);
    void run(force);
    return () => { controller.abort(); window.clearInterval(timer); remove(); workspaceWrites.removeEventListener("change", refresh); };
  }, [active, owner, online, request]);

  const sync: SyncState = scope === "demo" ? "preview" : !active ? "local" : online ? status : "paused";
  return { sync, syncNow };
}

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const mode = usePreferences((state) => state.mode);
  const { session, ready } = useAuth();
  const owner = session?.user.id;
  const scope: Scope = mode === "demo" ? "demo" : mode === "account" && owner ? `account:${owner}` : "local";
  const online = useOnline();
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: workspaceKey(scope), queryFn: () => openWorkspace(scope), staleTime: Infinity, networkMode: "always", retry: false });
  const { sync, syncNow } = useSync(scope, owner, online);

  useEffect(() => {
    if (!query.isSuccess) return;
    const subscription = liveQuery(() => readWorkspace(scope)).subscribe({
      next: (data) => queryClient.setQueryData(workspaceKey(scope), data),
      error: () => { void queryClient.invalidateQueries({ queryKey: workspaceKey(scope) }); },
    });
    return () => subscription.unsubscribe();
  }, [scope, queryClient, query.isSuccess]);

  return <Context.Provider value={{ scope, data: query.data ?? blank, loading: query.isPending || (mode === "account" && !ready), problem: query.isError, reload: () => { void query.refetch(); }, online, sync, syncNow }}>{children}</Context.Provider>;
}

export function useWorkspace() {
  const value = useContext(Context);
  if (!value) throw new Error("WorkspaceProvider is missing.");
  return value;
}