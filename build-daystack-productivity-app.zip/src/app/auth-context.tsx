import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { cloudAuthConfigured, observeSession } from "@/data/auth-repository";

interface AuthState { session: Session | null; ready: boolean; configured: boolean }
const AuthContext = createContext<AuthState>({ session: null, ready: true, configured: false });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(!cloudAuthConfigured);
  useEffect(() => observeSession((next) => {
      setSession(next);
      setReady(true);
  }), []);

  return <AuthContext.Provider value={{ session, ready, configured: cloudAuthConfigured }}>{children}</AuthContext.Provider>;
}

export function useAuth() { return useContext(AuthContext); }