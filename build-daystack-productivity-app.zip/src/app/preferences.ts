import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Theme = "light" | "dark" | "system";
export type WorkspaceMode = "demo" | "local" | "account";

interface Preferences {
  theme: Theme;
  mode: WorkspaceMode;
  collapsed: boolean;
  names: Record<string, string>;
  notifications: boolean;
  setTheme: (theme: Theme) => void;
  setMode: (mode: WorkspaceMode) => void;
  toggleSidebar: () => void;
  setName: (scope: string, value: string) => void;
  setNotifications: (enabled: boolean) => void;
}

export const usePreferences = create<Preferences>()(persist((set) => ({
  theme: "light",
  mode: "demo",
  collapsed: false,
  names: {},
  notifications: false,
  setTheme: (theme) => set({ theme }),
  setMode: (mode) => set({ mode }),
  toggleSidebar: () => set((state) => ({ collapsed: !state.collapsed })),
  setName: (scope, value) => set((state) => ({ names: { ...state.names, [scope]: value.trim().slice(0, 60) } })),
  setNotifications: (notifications) => set({ notifications }),
}), { name: "daystack-preferences-v1" }));