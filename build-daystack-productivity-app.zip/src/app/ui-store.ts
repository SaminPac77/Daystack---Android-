import { create } from "zustand";
import type { EntityKind } from "@/domain/models";

export interface CaptureRequest {
  type: "task" | "note";
  id?: string;
  projectId?: string;
  due?: string;
}

interface DeleteRequest { kind: EntityKind; id: string; title: string }
interface Toast { message: string; kind: "success" | "error" | "info"; key: number }

interface UiState {
  capture: CaptureRequest | null;
  search: boolean;
  authentication: boolean;
  deletion: DeleteRequest | null;
  toast: Toast | null;
  setCapture: (value: CaptureRequest | null) => void;
  setSearch: (value: boolean) => void;
  setAuthentication: (value: boolean) => void;
  setDeletion: (value: DeleteRequest | null) => void;
  notify: (message: string, kind?: Toast["kind"]) => void;
  clearToast: (key: number) => void;
  closeDialogs: () => void;
}

let toastCount = 0;
export const useUi = create<UiState>((set) => ({
  capture: null, search: false, authentication: false, deletion: null, toast: null,
  setCapture: (capture) => set({ capture }),
  setSearch: (search) => set({ search }),
  setAuthentication: (authentication) => set({ authentication }),
  setDeletion: (deletion) => set({ deletion }),
  notify: (message, kind = "success") => set({ toast: { message, kind, key: ++toastCount } }),
  clearToast: (key) => set((state) => state.toast?.key === key ? { toast: null } : state),
  closeDialogs: () => set({ capture: null, search: false, authentication: false, deletion: null }),
}));