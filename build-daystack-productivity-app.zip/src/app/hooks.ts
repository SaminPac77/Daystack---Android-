import { useEffect, useLayoutEffect, useState, useSyncExternalStore } from "react";
import { platform } from "@/platform/platform";
import { usePreferences } from "./preferences";

export function useOnline() {
  return useSyncExternalStore(platform.onConnection, platform.online, () => true);
}

export function useClock() {
  const [date, setDate] = useState(() => new Date());
  useEffect(() => {
    const update = () => setDate(new Date());
    const id = window.setInterval(update, 30_000);
    const remove = platform.onResume(update);
    return () => { window.clearInterval(id); remove(); };
  }, []);
  return date;
}

const darkQuery = "(prefers-color-scheme: dark)";
function subscribeColorScheme(callback: () => void) {
  const media = window.matchMedia(darkQuery);
  media.addEventListener("change", callback);
  return () => media.removeEventListener("change", callback);
}

export function useResolvedTheme() {
  const theme = usePreferences((state) => state.theme);
  const systemDark = useSyncExternalStore(subscribeColorScheme, () => window.matchMedia(darkQuery).matches, () => false);
  return theme === "system" ? systemDark ? "dark" : "light" : theme;
}

export function useApplyTheme() {
  const actual = useResolvedTheme();
  useLayoutEffect(() => {
    document.documentElement.dataset.theme = actual;
    document.documentElement.style.colorScheme = actual;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", actual === "dark" ? "#101B30" : "#F5F3EE");
  }, [actual]);
}