import { useEffect } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ChartNoAxesColumnIncreasing, Flame } from "lucide-react";
import { AuthProvider } from "@/app/auth-context";
import { useApplyTheme } from "@/app/hooks";
import { usePreferences } from "@/app/preferences";
import { useWorkspace, WorkspaceProvider } from "@/app/workspace-context";
import { AppHeader } from "@/components/layout/app-header";
import { AppSidebar } from "@/components/layout/app-sidebar";
import { MobileNavigation } from "@/components/layout/mobile-navigation";
import { Overlays } from "@/components/layout/overlays";
import { PageHeading } from "@/components/page-heading";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { TodayScreen } from "@/features/today/today-screen";
import { PlanScreen } from "@/features/plan/plan-screen";
import { ProjectsScreen, ProjectDetailsScreen } from "@/features/projects/projects-screen";
import { FocusScreen } from "@/features/focus/focus-screen";
import { useFocusAlarm } from "@/features/focus/focus-timer";
import { NotesScreen } from "@/features/notes/notes-screen";
import { SettingsScreen } from "@/features/settings/settings-screen";

const queryClient = new QueryClient({ defaultOptions: { queries: { networkMode: "always", refetchOnWindowFocus: false }, mutations: { networkMode: "always" } } });

function PlannedScreen({ name }: { name: "Habits" | "Insights" }) {
  return <div className="surface-container feature-page"><PageHeading title={name} eyebrow="DAYSTACK roadmap" description={name === "Habits" ? "Build routines at your own pace." : "Reflect on where your time went."} /><div className="panel"><EmptyState icon={name === "Habits" ? Flame : ChartNoAxesColumnIncreasing} title={`${name} aren't in this release`} description="This first release is focused on planning your day and getting tasks done." action={<Button asChild variant="outline"><Link to="/today">Back to Today</Link></Button>} /></div></div>;
}

function WorkspaceShell() {
  useApplyTheme();
  const collapsed = usePreferences((state) => state.collapsed);
  const { scope, loading, problem, reload } = useWorkspace();
  const { pathname } = useLocation();
  useFocusAlarm(scope);
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  const blocked = pathname !== "/today" && pathname !== "/settings" && pathname !== "/" && (loading || problem);
  return <div className={`app-shell${collapsed ? " sidebar-collapsed" : ""}`}>
    <a href="#page-content" className="skip-link">Skip to content</a>
    <AppSidebar />
    <div className="app-main">
      <AppHeader />
      <main id="page-content" tabIndex={-1}>
        {blocked ? <div className="surface-container">{loading ? <LoadingState /> : <ErrorState retry={reload} />}</div> : <Routes key={scope}>
          <Route path="/" element={<Navigate to="/today" replace />} />
          <Route path="/today" element={<TodayScreen />} />
          <Route path="/plan" element={<PlanScreen />} />
          <Route path="/projects" element={<ProjectsScreen />} />
          <Route path="/projects/:id" element={<ProjectDetailsScreen />} />
          <Route path="/focus" element={<FocusScreen />} />
          <Route path="/notes" element={<NotesScreen />} />
          <Route path="/habits" element={<PlannedScreen name="Habits" />} />
          <Route path="/insights" element={<PlannedScreen name="Insights" />} />
          <Route path="/settings" element={<SettingsScreen />} />
          <Route path="*" element={<Navigate to="/today" replace />} />
        </Routes>}
      </main>
    </div>
    <MobileNavigation />
    <Overlays />
  </div>;
}

export default function App() {
  return <QueryClientProvider client={queryClient}><BrowserRouter><AuthProvider><WorkspaceProvider><WorkspaceShell /></WorkspaceProvider></AuthProvider></BrowserRouter></QueryClientProvider>;
}
