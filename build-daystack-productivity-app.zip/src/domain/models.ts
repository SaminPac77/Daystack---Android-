export type Scope = "demo" | "local" | `account:${string}`;
export type Priority = "none" | "low" | "medium" | "high";
export type ProjectTone = "violet" | "sky" | "amber" | "sage";

export interface VersionedRecord {
  id: string;
  scope: Scope;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
  version: number;
}

export interface UserProfile extends VersionedRecord {
  displayName: string;
  language: string;
  notificationsEnabled: boolean;
}

export interface Workspace extends VersionedRecord {
  name: string;
  ownerId: string | null;
}

export interface Task extends VersionedRecord {
  title: string;
  description: string;
  projectId: string | null;
  status: "open" | "completed";
  priority: Priority;
  dueAt: string | null;
  completedAt: string | null;
}

export interface Project extends VersionedRecord {
  name: string;
  description: string;
  status: "active" | "archived";
  tone: ProjectTone;
}

export interface Note extends VersionedRecord {
  title: string;
  body: string;
  projectId: string | null;
}

export interface Habit extends VersionedRecord {
  title: string;
  weekdays: number[];
  archived: boolean;
}

export interface HabitLog extends VersionedRecord {
  habitId: string;
  day: string;
  completedAt: string;
}

export interface FocusSession extends VersionedRecord {
  taskId: string | null;
  startedAt: string;
  endedAt: string;
  durationSeconds: number;
}

export interface Reminder extends VersionedRecord {
  taskId: string;
  remindAt: string;
  deliveredAt: string | null;
}

export interface DayPlan {
  scope: Scope;
  day: string;
  slots: [string | null, string | null, string | null];
}

export interface EntityMap {
  task: Task;
  project: Project;
  note: Note;
}

export type EntityKind = keyof EntityMap;
export type SyncedEntity = {
  [K in EntityKind]: { kind: K; payload: EntityMap[K] }
}[EntityKind];

export interface SyncOperation {
  id: string;
  scope: Scope;
  record: SyncedEntity;
  attempts: number;
  retryAt: number;
}

export interface WorkspaceData {
  tasks: Task[];
  projects: Project[];
  notes: Note[];
  plans: DayPlan[];
  pending: number;
}