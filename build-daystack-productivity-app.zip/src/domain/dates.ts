const two = (value: number) => String(value).padStart(2, "0");

export function dayKey(date: Date | string): string {
  const local = typeof date === "string" ? new Date(date) : date;
  return `${local.getFullYear()}-${two(local.getMonth() + 1)}-${two(local.getDate())}`;
}

export function localDate(key: string) {
  return new Date(`${key}T12:00:00`);
}

export function shiftDay(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function dateToTimestamp(key: string) {
  return key ? localDate(key).toISOString() : null;
}

export function readableDate(date: Date | string, options: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat("en", options).format(typeof date === "string" ? new Date(date) : date);
}

export function greeting(date: Date) {
  const hours = date.getHours();
  return hours < 12 ? "Good morning" : hours < 18 ? "Good afternoon" : "Good evening";
}

export function newId() {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}