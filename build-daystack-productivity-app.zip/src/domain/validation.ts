import { z } from "zod";
import { dayKey, localDate } from "./dates";

export const uuid = z.uuid();
export const prioritySchema = z.enum(["none", "low", "medium", "high"]);
export const toneSchema = z.enum(["violet", "sky", "amber", "sage"]);
const timestamp = z.iso.datetime();
export const dateField = z.string().refine((value) => {
  if (value === "") return true;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  return dayKey(localDate(value)) === value;
}, "Enter a valid date.");

const projectId = uuid.nullable();
const title = z.string().trim().min(1, "Enter a title.").max(160, "Keep the title under 160 characters.");
const content = z.string().max(6000, "Keep the text under 6,000 characters.");

export const captureSchema = z.object({
  type: z.enum(["task", "note"]),
  title,
  description: content,
  priority: prioritySchema,
  due: dateField,
  project: z.union([z.literal(""), uuid]),
});

export const taskFields = z.object({ title, description: content, projectId, priority: prioritySchema, dueAt: timestamp.nullable() });
export const noteFields = z.object({ title, body: content, projectId });
export const projectFields = z.object({
  name: z.string().trim().min(1, "Enter a project name.").max(100, "Keep the name under 100 characters."),
  description: z.string().max(2000, "Keep the description under 2,000 characters."),
  tone: toneSchema,
});

const recordFields = z.object({
  id: uuid,
  createdAt: timestamp,
  updatedAt: timestamp,
  deletedAt: timestamp.nullable(),
  version: z.number().int().min(1).max(2147483647),
});

export const cloudEnvelope = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("task"), payload: recordFields.extend(taskFields.shape).extend({ status: z.enum(["open", "completed"]), completedAt: timestamp.nullable() }) }),
  z.object({ kind: z.literal("project"), payload: recordFields.extend(projectFields.shape).extend({ status: z.enum(["active", "archived"]) }) }),
  z.object({ kind: z.literal("note"), payload: recordFields.extend(noteFields.shape) }),
]);

export const authFields = z.object({
  email: z.email("Enter a valid email address."),
  password: z.string().min(8, "Use at least 8 characters.").max(128),
});

export type CaptureValues = z.infer<typeof captureSchema>;
export type TaskFields = z.infer<typeof taskFields>;
export type NoteFields = z.infer<typeof noteFields>;
export type ProjectFields = z.infer<typeof projectFields>;