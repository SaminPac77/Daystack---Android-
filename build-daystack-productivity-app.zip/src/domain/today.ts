import type { DayPlan, Priority, Task } from "./models";
import { dayKey } from "./dates";

const priorityWeight: Record<Priority, number> = { high: 3, medium: 2, low: 1, none: 0 };

export function getToday(tasks: Task[], day: string) {
  const today: Task[] = [];
  const overdue: Task[] = [];
  const upcoming: Task[] = [];

  for (const task of tasks) {
    if (task.deletedAt) continue;
    const due = task.dueAt ? dayKey(task.dueAt) : null;
    const completedToday = task.completedAt && dayKey(task.completedAt) === day;
    if (due === day || completedToday || (!due && task.status === "open" && dayKey(task.createdAt) === day)) today.push(task);
    else if (due && task.status === "open") (due < day ? overdue : upcoming).push(task);
  }

  const sortDue = (a: Task, b: Task) => (a.dueAt ?? "").localeCompare(b.dueAt ?? "");
  today.sort((a, b) => Number(a.status === "completed") - Number(b.status === "completed") || priorityWeight[b.priority] - priorityWeight[a.priority] || sortDue(a, b) || a.title.localeCompare(b.title));
  const completed = today.filter((task) => task.status === "completed").length;
  return { today, overdue: overdue.sort(sortDue), upcoming: upcoming.sort(sortDue), completed, percent: today.length ? Math.round(completed * 100 / today.length) : 0 };
}

export function prioritySlots(tasks: Task[], todaysTasks: Task[], plan?: DayPlan): DayPlan["slots"] {
  if (plan) {
    const valid = new Set(tasks.filter((task) => !task.deletedAt).map((task) => task.id));
    return plan.slots.map((id) => id && valid.has(id) ? id : null) as DayPlan["slots"];
  }
  const choices = todaysTasks.filter((task) => task.status === "open" && priorityWeight[task.priority] >= 2);
  return [choices[0]?.id ?? null, choices[1]?.id ?? null, choices[2]?.id ?? null];
}

export function isNewer(candidate: Pick<Task, "version" | "updatedAt">, existing: Pick<Task, "version" | "updatedAt">) {
  return candidate.version > existing.version || (candidate.version === existing.version && candidate.updatedAt > existing.updatedAt);
}