import { describe, expect, it } from "vitest";
import { dateToTimestamp, dayKey, localDate } from "./dates";
import type { Task } from "./models";
import { getToday, isNewer, prioritySlots } from "./today";
import { dateField, taskFields } from "./validation";

const date = "2026-11-26";
const createdAt = localDate(date).toISOString();

function task(id: string, values: Partial<Task> = {}): Task {
  return { id, scope: "local", title: id, description: "", status: "open", priority: "none", dueAt: null, projectId: null, deletedAt: null, completedAt: null, createdAt, updatedAt: createdAt, version: 1, ...values };
}

describe("Today selectors", () => {
  it("groups work by local day, ignores tombstones, and counts actual completions", () => {
    const records = [
      task("created today"),
      task("due today", { dueAt: dateToTimestamp(date), priority: "high" }),
      task("past due", { dueAt: dateToTimestamp("2026-11-25") }),
      task("due later", { dueAt: dateToTimestamp("2026-11-29") }),
      task("finished today", { completedAt: createdAt, status: "completed", dueAt: dateToTimestamp("2026-11-25") }),
      task("discarded", { deletedAt: createdAt }),
    ];
    const day = getToday(records, date);
    expect(day.today.map(({ id }) => id)).toEqual(["due today", "created today", "finished today"]);
    expect(day.overdue.map(({ id }) => id)).toEqual(["past due"]);
    expect(day.upcoming.map(({ id }) => id)).toEqual(["due later"]);
    expect(day.completed).toBe(1);
    expect(day.percent).toBe(33);
    expect(getToday([], date).percent).toBe(0);
  });

  it("prefills open important tasks and preserves deliberate empty slots", () => {
    const tasks = [task("one", { priority: "high" }), task("two", { priority: "medium" }), task("three")];
    expect(prioritySlots(tasks, tasks)).toEqual(["one", "two", null]);
    expect(prioritySlots(tasks, tasks, { scope: "local", day: date, slots: [null, "missing", "three"] })).toEqual([null, null, "three"]);
  });

  it("orders conflicting changes by version before timestamp", () => {
    expect(isNewer({ version: 2, updatedAt: "2026-11-25" }, { version: 1, updatedAt: "2026-11-26" })).toBe(true);
    expect(isNewer({ version: 2, updatedAt: "2026-11-25" }, { version: 2, updatedAt: "2026-11-26" })).toBe(false);
    expect(isNewer({ version: 2, updatedAt: "2026-11-26" }, { version: 2, updatedAt: "2026-11-25" })).toBe(true);
  });
});

describe("Task input", () => {
  it("validates calendar dates and round-trips local dates through UTC", () => {
    expect(dateField.safeParse("2026-02-31").success).toBe(false);
    expect(dateField.safeParse("2028-02-29").success).toBe(true);
    expect(dayKey(dateToTimestamp(date)!)).toBe(date);
  });

  it("rejects empty titles without requiring a project or deadline", () => {
    const input = { title: "  Write a plan  ", description: "", projectId: null, priority: "none", dueAt: null };
    expect(taskFields.parse(input).title).toBe("Write a plan");
    expect(taskFields.safeParse({ ...input, title: " " }).success).toBe(false);
  });
});