import { Capacitor } from "@capacitor/core";

export function registerAppShell() {
  if (!import.meta.env.PROD || Capacitor.isNativePlatform() || !("serviceWorker" in navigator)) return;
  void navigator.serviceWorker.register("/sw.js").catch((error: unknown) => {
    console.warn("DAYSTACK could not cache the offline shell.", error);
  });
}