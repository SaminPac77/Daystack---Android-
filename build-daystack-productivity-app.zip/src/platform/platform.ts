import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";

interface NativeApp {
  addListener(event: "appStateChange", callback: (state: { isActive: boolean }) => void): Promise<PluginListenerHandle>;
}
interface NativeHaptics {
  impact(options: { style: "LIGHT" }): Promise<void>;
}
interface NativeNotifications {
  requestPermissions(): Promise<{ display: string }>;
  schedule(options: { notifications: { id: number; title: string; body: string }[] }): Promise<unknown>;
}

const app = registerPlugin<NativeApp>("App");
const haptics = registerPlugin<NativeHaptics>("Haptics");
const notifications = registerPlugin<NativeNotifications>("LocalNotifications");

export const platform = {
  capabilities() {
    return { native: Capacitor.isNativePlatform(), notifications: Capacitor.isPluginAvailable("LocalNotifications") || ("Notification" in window && "serviceWorker" in navigator), haptics: Capacitor.isPluginAvailable("Haptics") };
  },
  online: () => navigator.onLine,
  onConnection(callback: () => void) {
    window.addEventListener("online", callback);
    window.addEventListener("offline", callback);
    return () => { window.removeEventListener("online", callback); window.removeEventListener("offline", callback); };
  },
  onResume(callback: () => void) {
    const onVisible = () => { if (!document.hidden) callback(); };
    document.addEventListener("visibilitychange", onVisible);
    const handle = Capacitor.isPluginAvailable("App") ? app.addListener("appStateChange", ({ isActive }) => { if (isActive) callback(); }) : null;
    return () => { document.removeEventListener("visibilitychange", onVisible); void handle?.then((listener) => listener.remove()).catch(() => {}); };
  },
  async lightFeedback() {
    if (Capacitor.isPluginAvailable("Haptics")) await haptics.impact({ style: "LIGHT" });
  },
  async allowNotifications() {
    if (Capacitor.isPluginAvailable("LocalNotifications")) return (await notifications.requestPermissions()).display === "granted";
    return "Notification" in window && await Notification.requestPermission() === "granted";
  },
  async notify(title: string, body: string) {
    if (Capacitor.isPluginAvailable("LocalNotifications")) {
      await notifications.schedule({ notifications: [{ id: Date.now() % 2147483647, title, body }] });
    } else if ("Notification" in window && Notification.permission === "granted") {
      const registration = await navigator.serviceWorker?.getRegistration();
      await registration?.showNotification(title, { body, icon: "/icons/daystack.svg" });
    }
  },
  download(name: string, content: Blob) {
    const url = URL.createObjectURL(content);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
};