\set ON_ERROR_STOP on
begin;

-- A disposable PostgreSQL database stands in for Supabase's Auth schema.
create role anon nologin;
create role authenticated nologin;
create schema auth;
create table auth.users (id uuid primary key);
create function auth.uid() returns uuid language sql stable as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
$$;
grant usage on schema auth, public to anon, authenticated;

\ir ../migrations/202611260001_workspace_records.sql

insert into auth.users values ('a288fb57-216b-4068-bfa4-e0907260aa65'), ('0bcf854b-43f9-4594-9d58-69aededb156a');
set local role authenticated;
select set_config('request.jwt.claim.sub', 'a288fb57-216b-4068-bfa4-e0907260aa65', true);

do $$
declare
  owner uuid := auth.uid();
  record_id uuid := '06fb2cfb-8084-45b3-9da6-f02f8b4069df';
  stamp text := '2026-11-26T16:00:00Z';
  body jsonb := jsonb_build_object('id', record_id, 'version', 1, 'createdAt', stamp, 'updatedAt', stamp, 'deletedAt', null, 'title', 'First write');
begin
  perform public.apply_daystack_record(owner, record_id, 'task', body, 1, stamp::timestamptz);
  perform public.apply_daystack_record(owner, record_id, 'task', body || '{"version":2,"title":"Second write"}', 2, stamp::timestamptz);
  perform public.apply_daystack_record(owner, record_id, 'task', body, 1, stamp::timestamptz);
  if (select count(*) from public.daystack_records) <> 1 or
    (select payload->>'title' from public.daystack_records where id = record_id) is distinct from 'Second write' then
    raise exception 'Idempotent version ordering failed';
  end if;

  perform set_config('request.jwt.claim.sub', '0bcf854b-43f9-4594-9d58-69aededb156a', true);
  if exists (select 1 from public.daystack_records) then raise exception 'Cross-user read was allowed'; end if;
  update public.daystack_records set kind = 'note' where id = record_id;
  if found then raise exception 'Cross-user update was allowed'; end if;

  begin
    insert into public.daystack_records values (owner, record_id, 'task', body, 1, stamp::timestamptz);
    raise exception 'Cross-user insert was allowed';
  exception when insufficient_privilege then null;
  end;
  begin
    perform public.apply_daystack_record(owner, record_id, 'task', body, 1, stamp::timestamptz);
    raise exception 'Cross-user RPC was allowed';
  exception when insufficient_privilege then null;
  end;
end;
$$;

set local role anon;
do $$
begin
  perform 1 from public.daystack_records;
  raise exception 'Anonymous read was allowed';
exception when insufficient_privilege then null;
end;
$$;

rollback;