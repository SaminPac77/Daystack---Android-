-- Local tables stay normalized. The cloud table is a versioned sync envelope.
create table public.daystack_records (
  owner_id uuid not null references auth.users(id) on delete cascade,
  id uuid not null,
  kind text not null check (kind in ('task', 'project', 'note')),
  payload jsonb not null,
  version integer not null check (version > 0),
  updated_at timestamptz not null,
  primary key (owner_id, id),
  check (jsonb_typeof(payload) = 'object' and payload ?& array['id', 'version', 'updatedAt', 'createdAt', 'deletedAt']),
  check ((payload->>'id' = id::text and (payload->>'version')::integer = version and (payload->>'updatedAt')::timestamptz = updated_at) is true)
);

alter table public.daystack_records enable row level security;
revoke all on public.daystack_records from public, anon, authenticated;
grant select, insert, update on public.daystack_records to authenticated;

create policy daystack_read_own on public.daystack_records
for select to authenticated using (owner_id = (select auth.uid()));

create policy daystack_insert_own on public.daystack_records
for insert to authenticated with check (owner_id = (select auth.uid()));

create policy daystack_update_own on public.daystack_records
for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));

create function public.apply_daystack_record(
  p_owner uuid, p_id uuid, p_kind text, p_payload jsonb, p_version integer, p_updated_at timestamptz
)
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if auth.uid() is null or auth.uid() is distinct from p_owner then
    raise exception 'Workspace ownership required' using errcode = '42501';
  end if;

  insert into public.daystack_records as current_record (owner_id, id, kind, payload, version, updated_at)
  values (p_owner, p_id, p_kind, p_payload, p_version, p_updated_at)
  on conflict (owner_id, id) do update set
    payload = excluded.payload,
    version = excluded.version,
    updated_at = excluded.updated_at
  where current_record.kind = excluded.kind
    and (excluded.version, excluded.updated_at) > (current_record.version, current_record.updated_at);
end;
$$;

revoke all on function public.apply_daystack_record(uuid, uuid, text, jsonb, integer, timestamptz) from public, anon;
grant execute on function public.apply_daystack_record(uuid, uuid, text, jsonb, integer, timestamptz) to authenticated;