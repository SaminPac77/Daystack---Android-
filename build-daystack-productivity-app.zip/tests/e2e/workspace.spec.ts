import { expect, test, type Page } from "@playwright/test";
import { readFile } from "node:fs/promises";

async function openPersonalWorkspace(page: Page) {
  await page.goto("/today");
  await expect(page.getByRole("heading", { name: "Top priorities" })).toBeVisible();
  await page.getByRole("button", { name: "Switch workspace (Demo workspace)" }).click();
  await page.getByRole("menuitem", { name: "My personal workspace" }).click();
  await expect(page.getByText("Nothing on your stack yet")).toBeVisible();
}

async function addTask(page: Page, title: string) {
  await page.getByRole("button", { name: "Quick Capture", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: "Quick Capture" });
  await dialog.getByLabel("Title", { exact: true }).fill(title);
  await dialog.getByRole("button", { name: "Add task", exact: true }).click();
  await expect(dialog).not.toBeVisible();
}

test("shows isolated demo data, navigable sidebar, and live priority slots", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/today$/);
  await expect(page.getByText("Demo workspace", { exact: true })).toBeVisible();
  await expect(page.getByRole("progressbar", { name: "Today's completion progress" })).toHaveAttribute("aria-valuenow", "40");
  await page.getByRole("button", { name: "Edit priorities" }).click();
  await page.getByLabel("Priority 1").selectOption("");
  await page.getByRole("button", { name: "Save priorities" }).click();
  await expect(page.getByRole("button", { name: /Set priority 1/ })).toBeVisible();
  await page.getByRole("button", { name: "Collapse sidebar" }).click();
  await page.getByRole("link", { name: "Plan", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Unscheduled", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Expand sidebar" }).click();
  await openPersonalWorkspace(page);
  await expect(page.getByRole("progressbar", { name: "Today's completion progress" })).toHaveAttribute("aria-valuenow", "0");
});

test("creates, edits, completes, filters, reloads, and deletes a task", async ({ page }) => {
  await openPersonalWorkspace(page);
  await addTask(page, "Draft a seminar question");
  await page.getByRole("button", { name: "Draft a seminar question", exact: true }).click();
  const edit = page.getByRole("dialog", { name: "Edit task" });
  await edit.getByLabel("Title", { exact: true }).fill("Polish the seminar question");
  await edit.getByLabel("Priority").selectOption("low");
  await edit.getByRole("button", { name: "Save changes" }).click();
  const checkbox = page.getByRole("checkbox", { name: "Complete Polish the seminar question" });
  await checkbox.click();
  await expect(checkbox).toBeChecked();
  await expect(page.getByRole("progressbar", { name: "Today's completion progress" })).toHaveAttribute("aria-valuenow", "100");
  await page.getByRole("button", { name: "Open", exact: true }).click();
  await expect(page.getByText("Nothing left open")).toBeVisible();
  await page.getByRole("button", { name: "Completed", exact: true }).click();
  await expect(checkbox).toBeVisible();
  await page.reload();
  await expect(checkbox).toBeChecked();
  await page.getByRole("button", { name: "Actions for Polish the seminar question" }).click();
  await page.getByRole("menuitem", { name: "Delete task" }).click();
  await page.getByRole("dialog", { name: "Delete task?" }).getByRole("button", { name: "Delete task" }).click();
  await expect(page.getByText("Nothing on your stack yet")).toBeVisible();
  await page.reload();
  await expect(checkbox).toHaveCount(0);
});

test("creates a project and a formatted note, finds it by keyboard, and preserves it when deleting the project", async ({ page }) => {
  await openPersonalWorkspace(page);
  await page.getByRole("link", { name: "Projects", exact: true }).click();
  await page.getByRole("button", { name: "New project", exact: true }).first().click();
  const projectForm = page.getByRole("dialog", { name: "New project" });
  await projectForm.getByLabel("Project name").fill("Film Club");
  await projectForm.getByRole("button", { name: "Create project" }).click();
  await expect(page.getByRole("heading", { name: "Film Club" })).toBeVisible();
  const projectUrl = page.url();
  await page.getByRole("button", { name: "Add note", exact: true }).click();
  const note = page.getByRole("dialog", { name: "Quick Capture" });
  await note.getByLabel("Title", { exact: true }).fill("Screening list");
  await note.getByLabel("Note optional").fill("**Opening night**\n- Projector test");
  await note.getByRole("button", { name: "Add note", exact: true }).click();
  await expect(page.locator("strong", { hasText: "Opening night" })).toBeVisible();
  await page.keyboard.press("Control+k");
  await page.getByRole("searchbox", { name: "Search tasks, notes, and projects" }).fill("projector");
  await page.keyboard.press("Enter");
  const edit = page.getByRole("dialog", { name: "Edit note" });
  await edit.getByLabel("Title", { exact: true }).fill("Screening checklist");
  await edit.getByRole("button", { name: "Save changes" }).click();
  await page.getByRole("button", { name: "Archive", exact: true }).click();
  await expect(page.getByText("Archived project", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Restore", exact: true }).click();
  await expect(page.getByText("Active project", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Delete", exact: true }).click();
  await page.getByRole("dialog", { name: "Delete project?" }).getByRole("button", { name: "Delete project" }).click();
  await expect(page).toHaveURL(/\/projects$/);
  await page.getByRole("link", { name: "Notes", exact: true }).click();
  await expect(page.getByRole("button", { name: "Screening checklist", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Actions for Screening checklist" }).click();
  await page.getByRole("menuitem", { name: "Delete note" }).click();
  await page.getByRole("dialog", { name: "Delete note?" }).getByRole("button", { name: "Delete note" }).click();
  await expect(page.getByText("No notes yet")).toBeVisible();
  await page.goto(projectUrl);
  await expect(page.getByText("Project not found")).toBeVisible();
});

test("loads the application shell, creates and edits tasks, and reloads with network disabled", async ({ page, context }) => {
  await openPersonalWorkspace(page);
  await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  await context.setOffline(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.locator("header").getByText("Offline", { exact: true })).toBeVisible();
  await addTask(page, "Outline lecture notes on the train");
  await page.getByRole("button", { name: "Outline lecture notes on the train", exact: true }).click();
  const edit = page.getByRole("dialog", { name: "Edit task" });
  await edit.getByLabel("Title", { exact: true }).fill("Review lecture notes on the train");
  await edit.getByRole("button", { name: "Save changes" }).click();
  await expect(edit).not.toBeVisible();
  await page.reload();
  await expect(page.getByRole("button", { name: "Review lecture notes on the train", exact: true })).toBeVisible();
  await expect(page.evaluate(async () => (await fetch("/images/daystack-compass.svg")).ok)).resolves.toBe(true);
  await page.close();
  const later = await context.newPage();
  await later.goto("/today");
  await expect(later.getByRole("button", { name: "Review lecture notes on the train", exact: true })).toBeVisible();
  await context.setOffline(false);
  await expect(later.locator("header").getByText("Offline", { exact: true })).not.toBeVisible();
});

test("reopens a running focus timer and supports pausing and resuming", async ({ page }) => {
  await page.goto("/today");
  await page.getByRole("link", { name: "Start a focus session" }).click();
  await page.getByRole("button", { name: "15 min", exact: true }).click();
  await expect(page.getByRole("timer")).toHaveText("15:00");
  await page.getByRole("button", { name: "Start focus", exact: true }).click();
  await page.reload();
  await expect(page.getByRole("button", { name: "Pause", exact: true })).toBeVisible();
  await expect(page.getByRole("timer")).not.toHaveText("15:00");
  await page.getByRole("button", { name: "Pause", exact: true }).click();
  await page.getByRole("button", { name: "Resume", exact: true }).click();
  await page.getByRole("button", { name: "Reset timer" }).click();
  await expect(page.getByRole("timer")).toHaveText("15:00");
});

test("exports only the active workspace from Settings", async ({ page }) => {
  await openPersonalWorkspace(page);
  await addTask(page, "Check backup scope");
  await page.getByRole("link", { name: "Settings", exact: true }).click();
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export data" }).click();
  const file = await download;
  expect(file.suggestedFilename()).toBe("daystack-backup.json");
  const data = JSON.parse(await readFile(await file.path(), "utf8"));
  expect(data).toMatchObject({ format: "daystack-v1", tasks: [{ title: "Check backup scope", scope: "local" }], projects: [], notes: [] });
});

test.describe("Mobile", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  test("exposes five-item navigation, quick capture, and persistent dark appearance", async ({ page }) => {
    await page.goto("/today");
    const bottom = page.getByRole("navigation", { name: "Mobile navigation" });
    await expect(bottom.getByRole("link")).toHaveCount(5);
    await expect(page.getByRole("navigation", { name: "Workspace", exact: true })).not.toBeVisible();
    await expect(page.getByRole("heading", { name: "Top priorities" })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
    await page.setViewportSize({ width: 320, height: 680 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(320);
    await page.setViewportSize({ width: 390, height: 844 });
    await addTask(page, "Return library books");
    await expect(page.getByRole("button", { name: "Return library books", exact: true })).toBeVisible();
    await bottom.getByRole("link", { name: "Profile", exact: true }).click();
    await page.getByRole("group", { name: "Appearance" }).getByRole("button", { name: "Dark", exact: true }).click();
    await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
    await page.reload();
    await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
    await page.getByRole("navigation", { name: "Other workspace tools" }).getByRole("link", { name: "Notes", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Notes", exact: true })).toBeVisible();
    await bottom.getByRole("link", { name: "Plan", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Plan", exact: true })).toBeVisible();
  });
});