const CACHE = "daystack-shell-v1";
const STATIC = ["/manifest.webmanifest", "/icons/daystack.svg", "/icons/daystack-192.png", "/icons/daystack-512.png", "/images/daystack-compass.svg"];
const WORKSPACE_ROUTE = /^\/(?:today|plan|projects(?:\/[a-f0-9-]+)?|focus|notes|habits|insights|settings)?\/?$/i;

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(["/", ...STATIC].map((path) => new Request(path, { cache: "reload" })))).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("daystack-shell-") && key !== CACHE).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;

  if (request.mode === "navigate" && WORKSPACE_ROUTE.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      try {
        const response = await fetch(request);
        if (response.ok && response.headers.get("content-type")?.includes("text/html")) await cache.put("/", response.clone());
        if (response.status < 500) return response;
      } catch {
        // Navigation works from the cached single-file Vite shell without a network.
      }
      return (await cache.match("/")) || Response.error();
    })());
  } else if (STATIC.includes(url.pathname)) {
    event.respondWith(caches.open(CACHE).then(async (cache) => (await cache.match(url.pathname)) || fetch(request)));
  }
});